# 🌟 Proyecto DGP 🌟

Bienvenido al repositorio del Proyecto DGP. Este proyecto está compuesto por un frontend en React, un backend en Node.js con Express, y una base de datos MariaDB desplegada en Docker.

## 📁 Estructura del Proyecto

El proyecto está ordenado por servicios de la siguiente forma:

```plaintext
📂 
├── 📁 api
├── 📁 mariadb
├── 📁 web_app
```


### 📂 api
Servicio Api 

- api.js: Punto de entrada, archivo que ejecuta contenedor para iniciar el servicio.
- server.js: Encapsulación de servidor
- db_connector.js: Módulo de conexión a la base de datos, configurado como un singleton para consultas seguras.
- Dockerfile: configuración para Docker

dependenciascors: express, cors, jsonwebtoken, mariadb


### 📂 mariadb
Servicio de base de datos
Esta carpeta contiene la configuración de la base de datos MariaDB:

- deploy.sql: Archivo SQL de inicialización para crear la base de datos y las tablas, e insertar el usuario admin.
- Dockerfile: configuración para Docker


### 📂 web_app
Servicio web

Se encarga de renderizar las paginas que ve el cliente. 
- src/components: Contiene los componentes de la aplicación
- src/styles: Contiene los CSS que utilzian los componentes
- App.js: Punto de entrada de la aplicación de React.
- Dockerfile: configuración para Docker



## 🚀 Despliegue con Docker
Para ejecutar el proyecto, utiliza el archivo docker-compose.yml en la raíz del repositorio:

```bash
docker-compose up --build
```
Este comando construirá y ejecutará los contenedores para cada servicio (base de datos, backend y frontend).

para parar ```CTRL-C```

para borrar ```docker compose down```


## 🌐 Endpoints y Funcionalidades
API de Autenticación:
- POST /api/login: Autenticación de usuario con JWT.

Frontend: Una vez autenticado, el usuario será redirigido a la página de inicio.




___
## Docker

### Instalación

Para la instalación de docker seguir los pasos de la documentación oficial disponible en este [enlace](https://docs.docker.com/engine/install/)

TLDR (Ubuntu):
```bash
# Add Docker's official GPG key:
sudo apt-get update
sudo apt-get install ca-certificates curl
sudo install -m 0755 -d /etc/apt/keyrings
sudo curl -fsSL https://download.docker.com/linux/ubuntu/gpg -o /etc/apt/keyrings/docker.asc
sudo chmod a+r /etc/apt/keyrings/docker.asc

# Add the repository to Apt sources:
echo \
  "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.asc] https://download.docker.com/linux/ubuntu \
  $(. /etc/os-release && echo "$VERSION_CODENAME") stable" | \
  sudo tee /etc/apt/sources.list.d/docker.list > /dev/null
sudo apt-get update
sudo apt-get install docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin

sudo groupadd docker
sudo usermod -aG docker $USER
newgrp docker
```

Para comprobar si se ha instalado correctamente: ```docker run hello-world```.

En el caso de errores revisar el estado de servicio y habilitarlo de ser necesario:
```
# Ver el estado
systemctl status dockerd

# Activar
systemctl start dockerd

# Habilitar para que se auto inicie siempre
systemctl enable dockerd
```


### Configuración
En el archivo ```docker-compose.yml``` vienen definidos los servicios que se van a desplegar y son los siguientes:
- db (database; mariadb)
- node (web server en el puerto 8080; nodejs)
- phpmyadmin (interfaz para la gestión de mariadb en el puerto 8081)

Para la información sobre la sintáxis consultar la documentación oficial disponible en este  [enlace](https://docs.docker.com/compose/)

### Despliegue
Haremos uso del modulo docker compose para desplegar una serie de contenedores dependientes. Para ello abrir terminal
en la raiz del proyecto y ejecutar ```docker compose up``` y para parar  CTRL-C

TLDR:

```
# desplegar contenedores
docker compose up

#  elimnar contenedores junto con sus redes y volumenes
docker compose down

# si he cambiado la configuración -> reconstruir
docker compose up --build
```
