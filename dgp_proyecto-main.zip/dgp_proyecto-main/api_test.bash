#!/bin/bash

echo "-> Solicitando token"
response=$(curl -s -X POST http://localhost:8080/api/auth \
  -H "Content-Type: application/json" \
  -d '{"username":"admin","password":"admin"}')

# Verificamos si se obtuvo un token
token=$(echo $response | jq -r '.token')

if [[ $token == "null" ]]; then
  echo "Error: No se pudo obtener un token. Respuesta del servidor: $response"
  exit 1
fi

echo "Token obtenido: $token"

echo "-> Estado de la base de datos"
db_status_response=$(curl -s -X GET http://localhost:8080/api/db_status \
  -H "Authorization: Bearer $token")

echo "Respuesta del estado de la base de datos: $db_status_response"

echo "-> Acceso a ruta restringida con token y siendo administrador"
user_response=$(curl -s -X GET http://localhost:8080/api/users \
  -H "Authorization: Bearer $token")

echo "Respuesta de la ruta de usuarios: $user_response"

echo "-> Acceso a ruta restringida sin token"
no_token_response=$(curl -s -X GET http://localhost:8080/api/users)

# Comprobamos el código de estado de la respuesta
if [[ $? -ne 0 ]]; then
  echo "Error al acceder a la ruta restringida sin token"
else
  echo "Respuesta de la ruta de usuarios sin token: $no_token_response"
fi
