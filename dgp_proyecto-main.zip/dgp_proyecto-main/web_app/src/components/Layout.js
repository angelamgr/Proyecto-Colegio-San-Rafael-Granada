import React, { useContext } from 'react';
import { AppContext } from '../AppContext';
import Header from './Header';
import Footer from './Footer';
import '../styles/Layout.css';


const Layout = ({ children }) => {
    const { userData } = useContext(AppContext);
    const userRole = userData.role;

    return (
        <div className="layout">
            <Header userRole={userRole} />
            <main>{children}</main>
            <Footer />
        </div>
    );
};

export default Layout;
