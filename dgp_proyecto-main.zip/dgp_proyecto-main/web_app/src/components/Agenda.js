import React, { useState, useEffect } from 'react';
import axios from 'axios';
import '../styles/Agenda.css';

const Agenda = () => {
    const [tasks, setTasks] = useState([]);
    const [error, setError] = useState(null);

    // Cargar la lista de estudiantes al montar el componente
    useEffect(() => {
        fetchTasksStudent();
    }, []);

    const fetchTasksStudent = async () => {
        try {
            const token = localStorage.getItem('token'); // o cómo estés almacenando el token
            const tokenPayload = JSON.parse(atob(token.split('.')[1]));
            const id_student = tokenPayload.id_student;
            const response = await axios.get(`http://localhost:8080/api/tasks/${id_student}`, {
                headers: {
                    Authorization: `Bearer ${token}` // Incluye el token en los encabezados
                }
            });
            setTasks(response.data); // Guardar las tareas en el estado
        } catch (error) {
            console.error('Error al obtener las tareas:', error);
            setError('Error al obtener las tareas.'); // Manejo del error
        }
    };

    return (
        <div>
            {error && <p>{error}</p>}
            {tasks.map(task => (
                <div key={task.id_tarea} className='task'>
                    <h2>{task.nombre}</h2>
                    {task.imagen_ident && <img src={task.imagen_ident} alt={task.nombre} />}
                    <ul>
                        {task.pasos.map(paso => (
                            <li key={paso.id_paso}>
                                <p>Orden: {paso.orden}</p>
                                {paso.url_imagen && <img src={paso.url_imagen} alt={`Paso ${paso.orden}`} />}
                                {paso.url_video && <video src={paso.url_video} controls />}
                                <p>{paso.texto}</p>
                            </li>
                        ))}
                    </ul>
                </div>
            ))}
        {!error && tasks.length === 0 && <p>No hay tareas disponibles.</p>}
    </div>
);
};

export default Agenda;