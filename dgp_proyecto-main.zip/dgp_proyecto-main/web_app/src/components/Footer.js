import React from 'react';

const Footer = () => {
    return (
        <footer>
            <p>&copy; 2024 Prácticas DGP. Equipo SoftSprint</p>
        </footer>
    );
};

export default Footer;
