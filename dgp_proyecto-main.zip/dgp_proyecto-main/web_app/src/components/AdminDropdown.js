import React, { useState, useContext, useRef } from 'react';
import { AppContext } from '../AppContext';
import { useNavigate } from 'react-router-dom';
import icono_admin_sin from '../assets/perfil_admin_sin.png';
import '../styles/AdminDropdown.css';

const AdminDropdown = () => {
  const [dropdownOpen, setDropdownOpen] = useState(false);
  //const [menuPosition, setMenuPosition] = useState({ top: 0, left: 0 });
  const { userData, setUserData } = useContext(AppContext);
  const navigate = useNavigate();

  const imgRef = useRef(null);
  const userRole = userData.userRole;
  const icono_admin = userData.profileImage || icono_admin_sin;
  const isAuthenticated = !!userData.token;

  const toggleDropdown = () => {
    setDropdownOpen(!dropdownOpen);
  };

  const handleLogout = () => {
    // Limpiar el contexto y el almacenamiento local
    setUserData({});
    localStorage.removeItem('token');
    localStorage.removeItem('userRole');
    navigate('/'); // Redirigir al inicio
  };

  return userRole !== 'user' ? (
    <div className="adminDropdown">
      <img
        id="img_perfil_admin"
        ref={imgRef}
        src={isAuthenticated && userRole === 'admin' ? icono_admin : icono_admin_sin}
        alt="Admin Profile"
        onClick={toggleDropdown}
        style={{ cursor: 'pointer' }}
        className={dropdownOpen ? 'active' : ''}
      />
      {dropdownOpen && (
        <div className={`dropdown-menu ${dropdownOpen ? 'show' : ''}`}>
          {isAuthenticated ? (
            <>
              <button onClick={() => navigate('/edit_profile')}>Modificar Perfil</button>
              <button onClick={handleLogout}>Cerrar Sesión</button>
            </>
          ) : (
            <button onClick={() => navigate('/login')}>Acceder</button>
          )}
        </div>
      )}
    </div>
  ) : null;
};

export default AdminDropdown;
