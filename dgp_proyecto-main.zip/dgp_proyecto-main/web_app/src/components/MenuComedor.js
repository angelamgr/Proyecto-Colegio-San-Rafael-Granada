import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

const MenuComedor = () => {
  const [menus, setMenus] = useState([]);
  const [error, setError] = useState(null);
  const navigate = useNavigate();

  // Cargar la lista de menús al montar el componente
  useEffect(() => {
    fetchMenus();
  }, []);

  const fetchMenus = async () => {
    try {
      const token = localStorage.getItem('token');
      const response = await axios.get('http://localhost:8080/api/menus', {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });
      setMenus(response.data);
    } catch (error) {
      console.error('Error al obtener los menús:', error);
      setError('Error al obtener los menús.');
    }
  };

  const handleAddMenu = () => {
    navigate('/admin/add_menu');
  };

  const handleDeleteMenu = async (id) => {
    
    const confirmDelete = window.confirm('¿Estás seguro de que quieres eliminar este menú?');
    if (confirmDelete) {
      try {
        const token = localStorage.getItem('token');
        await axios.delete(`http://localhost:8080/api/menu/${id}`, {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });
        fetchMenus();
      } catch (error) {
        console.error('Error al eliminar el menú:', error);
        setError('Error al eliminar el menú.');
      }
      
    }
  };

  return (
    <div>
      <h2>Gestión de Menús</h2>

      <div className="button-container">
        <button className="button" onClick={handleAddMenu}>Añadir menú</button>
      </div>

      {error && <p style={{ color: 'red' }}>{error}</p>}

      <div className="menuList">
        {menus.length > 0 ? (
          menus.map((menu) => (
            <div key={menu.id_menu} className="menuCard">
              <h3>{menu.menu_nombre || 'Nombre no disponible'}</h3>
              <img 
              // Si la URL de la imagen no está disponible, se muestra la imagen por defecto
                src={menu.imagen_url}
                alt={menu.menu_nombre || 'Menu'}
                className="menuPhoto"
              />
              <button id="deleteButton" onClick={() => handleDeleteMenu(menu.id_menu)}>
                Eliminar
              </button>
            </div>
          ))
        ) : (
          <p>No hay menús registrados.</p>
        )}
      </div>
    </div>
  );
};

export default MenuComedor;
