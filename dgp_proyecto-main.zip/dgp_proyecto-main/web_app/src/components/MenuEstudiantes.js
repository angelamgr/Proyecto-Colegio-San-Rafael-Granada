import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import default_photo_url from '../assets/perfil_admin_sin.png'; // Imagen por defecto

const MenuEstudiante = () => {
  const [students, setStudents] = useState([]);
  const [error, setError] = useState(null); // Manejo de errores
  const navigate = useNavigate();

  // Cargar la lista de estudiantes al montar el componente
  useEffect(() => {
    fetchStudents();
  }, []);

  const fetchStudents = async () => {
    try {
      const token = localStorage.getItem('token'); // o cómo estés almacenando el token
      const response = await axios.get('http://localhost:8080/api/students', {
        headers: {
          Authorization: `Bearer ${token}` // Incluye el token en los encabezados
        }
      });
      setStudents(response.data);
      console.log('Estudiantes:', response.data);
    } catch (error) {
      console.error('Error al obtener los estudiantes:', error);
      setError('Error al obtener los estudiantes.'); // Manejo del error
    }
  };

  // Redireccionar a la página de creación de estudiantes
  const handleAddStudent = () => {
    navigate('/admin/add_student'); // Cambia esta ruta según cómo hayas configurado el router
  };

  return (
    <div>
      <h2>Gestión de Estudiantes</h2>
      
      <div className="button-container">
        {/* Botón para redirigir a la creación de estudiantes */}
        <button onClick={handleAddStudent}>Añadir Estudiante</button>
      </div>
      

      {/* Mostrar mensaje de error si existe */}
      {error && <p style={{ color: 'red' }}>{error}</p>}

      {/* Lista de estudiantes en tarjetas */}
      <div className="studentList">
        {students.length > 0 ? (
          students.map((student) => (
            <div key={student.id} className="studentCard">
              <img 
              // Si la URL de la imagen no está disponible, se muestra la imagen por defecto
                src={student.profileImage===null ? default_photo_url : student.profile_url}
                alt={"Foto del estudiante " + student.name || 'Estudiante'}
                className="studentPhoto"
              />
              <h3>{student.nombre || 'Nombre no disponible'}</h3>
              <p>{student.class || 'Clase no disponible'}</p>
            </div>
          ))
        ) : (
          <p>No hay estudiantes registrados.</p>
        )}
      </div>
    </div>
  );
};

export default MenuEstudiante;
