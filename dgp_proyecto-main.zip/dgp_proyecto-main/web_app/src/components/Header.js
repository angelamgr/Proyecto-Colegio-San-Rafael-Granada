import React from 'react';
import logo_colegio from '../assets/logo_colegio_san_rafael.png';
import AdminDropdown from './AdminDropdown'; // Importamos el nuevo componente

const Header = () => {
  return (
    <header>
      <img id="logo_colegio_header" src={logo_colegio} alt="Logo Colegio San Rafael" />
      <h1 id="titulo_header">AutonoMe</h1>
      <AdminDropdown />
    </header>
  );
};

export default Header;
