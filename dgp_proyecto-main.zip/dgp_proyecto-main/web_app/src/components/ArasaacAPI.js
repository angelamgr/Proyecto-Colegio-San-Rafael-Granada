import React, { useState } from "react";
import axios from "axios";

const ArasaacImages = () => {
  const [images, setImages] = useState([]);
  const [search, setSearch] = useState("");

  const fetchImages = async () => {
    try {
      const response = await axios.get(
        `https://api.arasaac.org/api/pictograms/es/search/${search}`
      );
      setImages(response.data);
    } catch (error) {
      console.error("Error fetching images:", error);
    }
  };

  const handleSearch = (e) => {
    setSearch(e.target.value);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    setImages([]);
    fetchImages();
  };

  return (
    <div>
      <form onSubmit={handleSubmit}>
        <input
          type="text"
          placeholder="Buscar pictogramas"
          value={search}
          onChange={handleSearch}
        />
        <button type="submit">Buscar</button>
      </form>

      <div>
        {images.map((image) => (
          <img
            key={image._id}
            src={`https://static.arasaac.org/pictograms/${image._id}/${image._id}_500.png`}
            alt={image.keywords[0]?.word || "Pictograma"}
            style={{ margin: "10px", width: "150px" }}
          />
        ))}
      </div>
    </div>
  );
};

export default ArasaacImages;
