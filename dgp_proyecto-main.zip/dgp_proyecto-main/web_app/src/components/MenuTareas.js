import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

const MenuTareas = () => {
  const [tasks, setTasks] = useState([]);
  const [error, setError] = useState(null);
  const navigate = useNavigate();

  // Cargar la lista de menús al montar el componente
  useEffect(() => {
    fetchTasks();
  }, []);

  const fetchTasks = async () => {
    try {
      const token = localStorage.getItem('token');
      const response = await axios.get('http://localhost:8080/api/tasks', {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });
      setTasks(response.data);
    } catch (error) {
      console.error('Error al obtener las tareas:', error);
      setError('Error al obtener las tareas.');
    }
  };

  const handleAddTask = () => {
    navigate('/admin/add_task');
  };

  const handleDeleteTask = async (id) => {
    
    const confirmDelete = window.confirm('¿Estás seguro de que quieres eliminar esta tarea?');
    if (confirmDelete) {
      try {
        const token = localStorage.getItem('token');
        await axios.delete(`http://localhost:8080/api/task/${id}`, {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });
        fetchTasks();
      } catch (error) {
        console.error('Error al eliminar la tarea:', error);
        setError('Error al eliminar la tarea.');
      }
      
    }
  };

  return (
    <div>
      <h2>Gestión de Tareas</h2>

      <div className="button-container">
        <button className="button" onClick={handleAddTask}>Añadir tarea</button>
      </div>

      {error && <p style={{ color: 'red' }}>{error}</p>}
      
      <div className="menuList">
        {tasks.length > 0 ? (
          tasks.map((task) => (
            <div key={task.id_tarea} className="menuCard">
              <img 
                src={task.imagen_ident || 'default_photo_url'} 
                alt={task.nombre || 'Tarea'}
                className="menuPhoto"
              />
              <h3>{task.nombre || 'Nombre no disponible'}</h3>
              <button id="deleteButton" onClick={() => handleDeleteTask(task.id_tarea)}>
                Eliminar
              </button>
            </div>
          ))
        ) : (
          <p>No hay tareas registradas.</p>
        )}
      </div>
      <button className="button" onClick={() => navigate('/admin/assign_task')}>Asignar Tareas</button>
    </div>
  );
};

export default MenuTareas;
