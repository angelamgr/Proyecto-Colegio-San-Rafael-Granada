import React, { useState } from 'react';
import axios from 'axios';

const UploadImage = ({ onImageUpload }) => {
    const [selectedImage, setSelectedImage] = useState(null);
    const [imagePreview, setImagePreview] = useState(null);

    const handleImageChange = (e) => {
        const file = e.target.files[0];
        if (file) {
            setSelectedImage(file);
            setImagePreview(URL.createObjectURL(file)); // Previsualiza la imagen
        }
    };

    const handleImageUpload = async () => {
        if (!selectedImage) {
            alert('Por favor selecciona una imagen');
            return;
        }

        const formData = new FormData();
        formData.append('profileImage', selectedImage);

        try {
            const response = await axios.post('http://localhost:8080/api/upload-profile-image', formData, {
                headers: {
                    'Content-Type': 'multipart/form-data',
                    'Authorization': `Bearer ${localStorage.getItem('token')}`, // Asegúrate de incluir el token
                },
            });

            onImageUpload(response.data.imageUrl); // Usar la URL de la imagen
        } catch (error) {
            console.error('Error al subir la imagen:', error);
            alert('Error al subir la imagen');
        }
    };

    return (
        <div>
            <input type="file" accept="image/*" onChange={handleImageChange} />
            {imagePreview && <img src={imagePreview} alt="Vista previa" style={{ width: '100px', height: '100px' }} />}
            <button onClick={handleImageUpload}>Subir Imagen</button>
        </div>
    );
};

export default UploadImage;
