import React, { useState, useEffect } from 'react';
import MenuEstudiante from './MenuEstudiantes';
import MenuComedor from './MenuComedor';
import MenuTareas from './MenuTareas';
import { AppProvider } from '../AppContext';

const Menuses = () => {
  const [activeTab, setActiveTab] = useState('menuEstudiante'); // Estado para la pestaña activa

  // Función para renderizar el menú activo
  const renderMenu = () => {
    switch (activeTab) {
      case 'menuEstudiante':
        return <MenuEstudiante />;
      case 'menuComedor':
        return <MenuComedor />;
      case 'menuTareas':
        return <MenuTareas />;
      default:
        return null;
    }
  };

  // Recuperar la última pestaña activa desde localStorage
  useEffect(() => {
    const lastTab = localStorage.getItem('activeTab');
    if (lastTab) {
      setActiveTab(lastTab);
    }
  }, []);

  // Guardar la pestaña activa en localStorage
  const handleTabClick = (tab) => {
    setActiveTab(tab);
    localStorage.setItem('activeTab', tab);
  };

  return (
    <AppProvider>
    <div>
      {/* Pestañas de navegación */}
      <nav className="navMenu">
        <button className={activeTab === 'menuEstudiante' ? 'tab activeTab' : 'tab'} onClick={() => handleTabClick('menuEstudiante')}>Estudiantes</button>
        <button className={activeTab === 'menuComedor' ? 'tab activeTab' : 'tab'} onClick={() => handleTabClick('menuComedor')}>Comedor</button>
        <button className={activeTab === 'menuTareas' ? 'tab activeTab' : 'tab'} onClick={() => handleTabClick('menuTareas')}>Tareas</button>
      </nav>

      {/* Contenido del menú */}
      <div className='contentMenu'>
        {renderMenu()}
      </div>
    </div>
    </AppProvider>
  );
};

export default Menuses;
