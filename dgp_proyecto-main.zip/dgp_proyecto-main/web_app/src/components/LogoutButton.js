import React, { useState, useContext, useRef } from 'react';
import { AppContext } from '../AppContext';
import { useNavigate } from 'react-router-dom';
import '../styles/LogoutButton.css';
import imgLogout from '../assets/logout.png';


const LogoutButton = () => {
  //const [menuPosition, setMenuPosition] = useState({ top: 0, left: 0 });
  const { userData, setUserData } = useContext(AppContext);
  const navigate = useNavigate();

  const handleLogout = () => {
    // Limpiar el contexto y el almacenamiento local
    setUserData({});
    localStorage.removeItem('token');
    localStorage.removeItem('userRole');
    navigate('/'); // Redirigir al inicio
  };

  return (
    <div className="logoutButton">
    <button id="logout" onClick={handleLogout}>
        <img className="boton-logout" src={imgLogout} alt="Cerrar sesión" />
        <span>CERRAR SESIÓN</span>
    </button>
    </div>
  );
};

export default LogoutButton;
