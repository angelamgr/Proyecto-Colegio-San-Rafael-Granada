import React, { createContext, useState, useEffect } from 'react';
import { jwtDecode } from 'jwt-decode';
//import { Navigate } from 'react-router-dom';

export const AppContext = createContext();

// Proveedor de la aplicación que almacena el estado global de la autenticación
// y proporciona funciones para iniciar sesión y cerrar sesión
export const AppProvider = ({ children }) => {
    const storedToken = localStorage.getItem('token') || null;

    // Función para obtener información del usuario desde el token (util al recargar la página)
    const getUserFromToken = (token) => {
        try {
            if (!token) {
                return { username: 'Guest', userRole: 'guest' };
            }
            const decoded = jwtDecode(token);
            let user_role = 'guest';

            if (decoded.id_rol === 1) {
                user_role = 'admin';
            }else if (decoded.id_rol === 2) {
                user_role = 'user';
            } else if (decoded.id_rol === 3) {
                user_role = 'guest';
            }

            return {
                username: decoded.username || 'Guest',
                userRole: user_role,
                isTokenExpired: decoded.exp < Date.now() / 1000
            };
        } catch (error) {
            console.error('Token inválido:', error);
            return { username: 'Guest', userRole: 'guest' };
        }
    };

    const [userData, setUserData] = useState({
        token: storedToken,
        ...getUserFromToken(storedToken),
        data: { preferences: {}, lastLogin: null }
    });

    const isTokenExpired = (token) => {
        try {
            const payload = JSON.parse(atob(token.split('.')[1]));
            if (payload.exp < Date.now() / 1000) {
                return true;
            } else {
                localStorage.removeItem('userData');
                return false;
            }
        } catch (error) {
            console.error('Error al verificar la expiración del token:', error);
            return true;
        }
    };

    useEffect(() => {
        if (userData.token) {
            localStorage.setItem('token', userData.token);
        }

        if (userData.token && isTokenExpired(userData.token)) {
            setUserData({
                token: null,
                username: 'Guest',
                userRole: 'guest',
                data: { preferences: {}, lastLogin: null }
            });
            localStorage.removeItem('token');
        }

        /*if(isTokenExpired(userData.token)){
            <Navigate to="/login" />;
        }*/
    }, [userData.token]);

    const logout = () => {
        setUserData({
            token: null,
            username: 'Guest',
            userRole: 'guest',
            data: { preferences: {}, lastLogin: null }
        });
        localStorage.removeItem('token');
    };

    const appContextValue = { userData, setUserData, logout };

    return (
        <AppContext.Provider value={appContextValue}>
            {children}
        </AppContext.Provider>
    );
};
