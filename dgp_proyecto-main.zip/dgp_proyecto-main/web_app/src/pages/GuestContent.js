import React from 'react';

const GuestContent = () => {
    return (
        <div>
            <h3>Perfiles de estudiantes</h3>
            <p>Aqui van todos los perfiles</p>
        </div>
    );
};

export default GuestContent;