import React, { useState, useContext, useEffect } from "react";
import { AppContext } from "../AppContext";
import Layout from "../components/Layout";
import axios from "axios";
import { jwtDecode } from "jwt-decode";
import { useNavigate, useLocation } from "react-router-dom";

const LoginStudent = () => {
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [pattern, setPattern] = useState([]);
  const [error, setError] = useState("");
  const [items, setItems] = useState([]);
  const navigate = useNavigate();
  const location = useLocation();

  const { setUserData } = useContext(AppContext);

  // Obtener datos del estudiante desde el estado
  const student = location.state;

  /* Si descomentas el componente se rompe
  if (!student) {
    return <p>Error: No se proporcionaron datos del estudiante.</p>;
  }
  */

  const { usuario, prefe_view } = student;

  // Función para obtener los distractores desde la API
  const getDistractors = async () => {
    try {
      console.log("Distractores para: ", usuario);
      const response = await axios.get(`http://localhost:8080/api/student/${usuario}/pwd_dist`);
      const pwd_dist = response.data;
      
      if (pwd_dist && Array.isArray(pwd_dist.images)) {

        const temp = pwd_dist.images.map((distractor, index) => (
          {
          id: index + 1,  
          src: `http://localhost:8080/images/${distractor.nombre}`, 
          alt: distractor.alt_text,
          id_img: distractor.id_img
        }));
        
        console.log("Distractores construidos: ", items);
        // Establecemos el estado con los distractores
        setItems(temp);
      } else {
        console.error("La estructura de datos no contiene 'images' como un array válido");
      }
  
    } catch (error) {
      console.error("Error al obtener las imágenes distractoras:", error);
    }
  };

  useEffect(() => {
    getDistractors();
  }, [usuario]); 

  
  // Método de inicio de sesión
  /*const onLogin = async (loginData) => {
    if(loginData.method!=="Texto"){
      loginData.input = loginData.input.map((item) => item.id_img) 
    }
    try {
      const response = await axios.post("http://localhost:8080/api/auth_student", {
        usuario,
        ...loginData
      });
      const { token } = response.data;

      // Decodificar token para obtener información adicional
      const decoded = jwtDecode(token);
      const { username: decodedUsername, id_rol: userRole, id_student: idStudent } = decoded;

      // Actualizar userData en AppContext
      setUserData({
        token,
        username: decodedUsername,
        userRole: userRole === 2 ? 'user' : 'guest',
        id_student: idStudent,
        profileImage: response.data.image ? response.data.image : null,
        data: {}
      });

      console.log("Inicio de sesión exitoso para:", decoded.usuario);
      localStorage.setItem("token", token);

      // Navegar a la pantalla del usuario
      navigate("/user");
    } catch (err) {
      console.error("Error al iniciar sesión:", err);
      setError("Error al iniciar sesión. Por favor, verifica tus credenciales.");
    }
  };*/
  const onLogin = async (loginData) => {
    if(loginData.method!=="Texto"){
      loginData.input = loginData.input.map((item) => item.id_img) 
    }
    try {
      const response = await axios.post("http://localhost:8080/api/auth_student", {
        usuario,
        ...loginData
      });
      const { token } = response.data;

      // Decodificar token para obtener información adicional
      const decoded = jwtDecode(token);
      const { nombre: decodedUsername, id_rol: userRole,id_student: idStudent } = decoded;
      // Actualizar userData en AppContext
      setUserData({
        token,
        username: decodedUsername,
      
        userRole: userRole === 2 ? 'user' : 'guest',
        id_student: idStudent,
        profileImage: response.data.image ? response.data.image : null,
        data: {}
      });
      console.log(decoded);
      console.log("Inicio de sesión exitoso para:", decoded.usuario,decoded.id_student);
      localStorage.setItem("token", token);

      // Navegar a la pantalla del usuario
      navigate("/user");
    } catch (err) {
      console.error("Error al iniciar sesión:", err);
      setError("Error al iniciar sesión. Por favor, verifica tus credenciales.");
    }
  };

  // Manejar el envío del formulario
  const handleSubmit = () => {
    if (prefe_view === "Texto" && password) {
      onLogin({ method: "Texto", input: password });
    } else if (["Imagenes", "Pictogramas", "Imagen+Texto", "Pictogramas+Texto"].includes(prefe_view) && pattern.length) {
      //const patternIds = pattern.map(item => item.id); // Solo enviar los IDs de las imágenes
      onLogin({ method: prefe_view, input: pattern });
    } else {
      setError("Por favor completa el campo necesario.");
    }
  };

  // Agregar un elemento al patrón
  const addToPattern = (item) => {
    if (pattern.length < 3 ){
      const newPattern = [...pattern, item];
    console.log("Patron actual:", newPattern);
      setPattern(newPattern);

      // Si el patrón está completo, intentar iniciar sesión automáticamente
      if (newPattern.length === 3) {
        onLogin({ method: prefe_view, input: newPattern });
      }
    }
  };

  // Eliminar el último elemento del patrón
  const removeLastFromPattern = () => {
    setPattern(pattern.slice(0, -1));
    setError("");  // Limpiar el mensaje de error
  };

  // Renderizar el input en función de la vista preferida
  const renderInput = () => {
    switch (prefe_view) {
      case "Texto":
        return (
          <div className="text-password">
            <input
              type={showPassword ? "text" : "password"}
              placeholder="Ingrese su contraseña"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
            <button
              type="button"
              onClick={() => setShowPassword(!showPassword)}
              style={{ marginLeft: "5px", cursor: "pointer" }}
            >
              {showPassword ? "Ocultar" : "Mostrar"}
            </button>
          </div>
        );

      case "Imagenes":
      case "Pictogramas":
        return (
          <div className="pattern-selector">
            <div className="items-grid">
              {items.map((item) => (
                <img
                  key={item.id}
                  src={item.src}
                  alt={item.alt}
                  onClick={() => addToPattern(item)}
                  style={{
                    width: "100px",
                    height: "100px",
                    cursor: "pointer",
                    margin: "5px",
                  }}
                />
              ))}
            </div>
            <div className="pattern-visualization">
              <p>Patrón seleccionado:</p>
              <div style={{ display: "flex", gap: "5px" }}>
                {pattern.map((item, index) => (
                  <img
                    key={index}
                    src={item.src}
                    alt={prefe_view === "Pictogramas" ? "" : item.alt}
                    style={{ width: "50px", height: "50px" }}
                  />
                ))}
              </div>
              <button type="button" onClick={removeLastFromPattern}>
                Deshacer
              </button>
            </div>
          </div>
        );

      case "Imagen+Texto":
      case "Pictogramas+Texto":
        return (
          <div className="pattern-selector">
            <div className="items-grid" style={{ display: "flex", gap: "5px" }}>
              {items.map((item) => (
                <div
                  key={item.id}
                  onClick={() => addToPattern(item)}
                  style={{
                    cursor: "pointer",
                    textAlign: "center",
                    margin: "5px",
                  }}
                >
                  <img
                    src={item.src}
                    alt={item.alt}
                    style={{
                      width: "100px",
                      height: "100px",
                      marginBottom: "5px",
                    }}
                  />
                  <p>{item.alt}</p>
                </div>
              ))}
            </div>
            <div className="pattern-visualization">
              <p>Patrón seleccionado:</p>
              <div style={{ display: "flex", gap: "5px", flexDirection: "row" }}>
                {pattern.map((item, index) => (
                  <div key={index} style={{ textAlign: "center" }}>
                    <img
                      src={item.src}
                      alt={item.alt}
                      style={{ width: "50px", height: "50px" }}
                    />
                    <p style={{ fontSize: "12px" }}>{item.alt}</p>
                  </div>
                ))}
              </div>
              <button type="button" onClick={removeLastFromPattern}>
                Deshacer
              </button>
            </div>
          </div>
        );

      default:
        return <p>Vista no soportada.</p>;
    }
  };

  return (
    <Layout>
      <div className="student-login">
        <h2>Inicio de Sesión para Estudiantes</h2>
        <p>Usuario: {usuario}</p>
        <p>Modo de inicio de sesión: {prefe_view}</p>
        {renderInput()}
        {error && <p style={{ color: "red" }}>{error}</p>}
        <button type="submit" onClick={handleSubmit}>Iniciar Sesión</button>
        <button type="button" onClick={() => {
          localStorage.setItem("id_student", student.id_student);
          navigate("/admin");
        }}>
          Volver
        </button>
      </div>
    </Layout>
  );
};

export default LoginStudent;
