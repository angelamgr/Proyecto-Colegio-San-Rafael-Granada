import React, { useState } from 'react';
import useAxios from '../axiosConfig';
import Layout from '../components/Layout';
import '../styles/tarea_pasos.css';
import { Link, useNavigate } from 'react-router-dom';

const FormularioTarea = () => {

  const axios = useAxios();
  const navigate = useNavigate();

  // Estado para la tarea
  const [nombre, setNombre] = useState('');
  const [imagenTarea, setImagenTarea] = useState(null);
  const [pasos, setPasos] = useState([]);

  // Estado para cada paso
  const [formPaso, setFormPaso] = useState({
    imagenPaso: null, // Imagen del paso (archivo)
    pictograma: null, // Pictograma (archivo)
    urlVideo: '',
    texto: ''
  });



  /*18-noviembre añadido para resetear el formulario cuando se añade nueva tarea. CODIGO NO TESTEADO */
  const resetFormulario = () => {
    setNombre('');
    setImagenTarea(null);
    setPasos([]);
    setFormPaso({
      imagenPaso: null,
      pictograma: null,
      urlVideo: '',
      texto: '',
    });
  };


  const handleSubmitTarea = async (event) => {
    event.preventDefault();

    // Crear un objeto FormData para enviar la tarea
    const formDataTarea = new FormData();

    // Añadir los campos de la tarea al FormData
    formDataTarea.append('nombre', nombre); // Campo de texto
    if (imagenTarea) formDataTarea.append('taskImage', imagenTarea); // Imagen principal

    try {
      // 1. Enviar la tarea al servidor
      const responseTarea = await axios.post('http://localhost:8080/api/add_task', formDataTarea, {
        headers: {
          'Content-Type': 'multipart/form-data', // Indicamos el tipo de contenido
        },
      });

      // Obtener el id_tarea de la respuesta
      const { idTarea } = responseTarea.data;
      console.log('Tarea creada con id:', idTarea);

      // 2. Crear los pasos en paralelo
      const promises = pasos.map((paso) => {
        const formDataPaso = new FormData();

        // Añadir campos al FormData para cada paso
        if (paso.imagen_paso) formDataPaso.append('stepImage', paso.imagen_paso);
        if (paso.pictograma) formDataPaso.append('pictoImage', paso.pictograma);
        formDataPaso.append('url_video', paso.url_video || '');
        formDataPaso.append('texto', paso.texto);
        formDataPaso.append('orden', paso.orden);
        formDataPaso.append('id_tarea', idTarea);

        // Enviar cada paso al servidor
        return axios.post('http://localhost:8080/api/add_step', formDataPaso, {
          headers: {
            'Content-Type': 'multipart/form-data',
          },
        });
      });

      // Esperar a que todas las promesas se resuelvan
      await Promise.all(promises);

      console.log('Todos los pasos fueron creados con éxito.');
      alert('Tarea y pasos creados con éxito');
      resetFormulario(); // Limpiar el formulario si es necesario
      navigate('/admin'); // Redirigir a la página de administración
    } catch (error) {
      alert('Error al crear la tarea o los pasos: ' + error.message);
      console.error('Error:', error);
    }
  };




  // Función para agregar paso
  const handleAddPaso = (e) => {
    e.preventDefault();

    // Validación: asegurarse de que 'texto' no esté vacío
    if (!formPaso.texto) {
      alert('El texto del paso es obligatorio.');
      return; // Evita agregar el paso si el texto está vacío
    }

    // Generar el orden automáticamente
    const nuevoOrden = pasos.length + 1;

    // Agregar el paso al estado
    setPasos([
      ...pasos,
      {
        orden: nuevoOrden,
        imagen_paso: formPaso.imagenPaso, // Imagen del paso
        pictograma: formPaso.pictograma, // Pictograma del paso
        url_video: formPaso.urlVideo,
        texto: formPaso.texto
      }
    ]);

    // Reiniciar el formulario de pasos
    setFormPaso({
      imagenPaso: null,
      pictograma: null,
      urlVideo: '',
      texto: ''
    });
  };

  // Función para mover el paso hacia arriba
  const movePasoUp = (index) => {
    if (index === 0) return; // No se puede mover el primer paso hacia arriba
    const newPasos = [...pasos];
    [newPasos[index - 1], newPasos[index]] = [newPasos[index], newPasos[index - 1]];
    setPasos(newPasos);
  };

  // Función para mover el paso hacia abajo
  const movePasoDown = (index) => {
    if (index === pasos.length - 1) return; // No se puede mover el último paso hacia abajo
    const newPasos = [...pasos];
    [newPasos[index + 1], newPasos[index]] = [newPasos[index], newPasos[index + 1]];
    setPasos(newPasos);
  };

  // Función para eliminar un paso
  const removePaso = (index) => {
    const newPasos = pasos.filter((_, i) => i !== index);
    setPasos(newPasos);
  };

  return (
    <Layout>
      <main className="tareas">
        <div>
          <h1 className="titulo1">Crear tarea</h1>

          <form onSubmit={handleSubmitTarea} className="formulario_tareas">
            <label htmlFor="nombre">Nombre Identificativo:</label>
            <input
              type="text"
              id="nombre"
              value={nombre}
              onChange={(e) => setNombre(e.target.value)}
              required
            />
            <br /><br />
            <label htmlFor="imagenTarea">Imagen Identificativa:</label>
            <input
              type="file"
              id="imagenTarea"
              onChange={(e) => setImagenTarea(e.target.files[0])}
            />
            <br /><br />

            {/* Previsualización de la imagen si existe */}
            {imagenTarea && (
                        <div className="image-preview-task-container">
                            <h3>Vista previa de la imagen de la tarea</h3>
                            <img
                                src={imagenTarea && URL.createObjectURL(imagenTarea)}
                                alt="Vista previa de la imagen"
                                className="image-preview"
                            />
                        </div>
                    )}

            <br /> <br />

            <h3>Añadir Paso</h3>
            <label htmlFor="imagenPaso">Imagen del paso:</label>
            <input
              type="file"
              id="imagenPaso"
              onChange={(e) => setFormPaso({ ...formPaso, imagenPaso: e.target.files[0] })}
            />
            {formPaso.imagenPaso && (
                        <div className="image-preview-task-container">
                            <h3>Vista previa de la imagen del paso</h3>
                            <img
                                src={formPaso.imagenPaso && URL.createObjectURL(formPaso.imagenPaso)}
                                alt="Vista previa de la imagen"
                                className="image-preview"
                            />
                        </div>
                    )}
            <br />
            <label htmlFor="pictograma">Pictograma:</label>
            <input
              type="file"
              id="pictograma"
              onChange={(e) => setFormPaso({ ...formPaso, pictograma: e.target.files[0] })}
            />
            {formPaso.pictograma && (
                        <div className="image-preview-task-container">
                            <h3>Vista previa del pictograma del paso</h3>
                            <img
                                src={formPaso.pictograma && URL.createObjectURL(formPaso.pictograma)}
                                alt="Vista previa de la imagen"
                                className="image-preview"
                            />
                        </div>
                    )}
            <br />
            <label htmlFor="urlVideo">URL del video:</label>
            <input
              type="text"
              id="urlVideo"
              value={formPaso.urlVideo}
              onChange={(e) => setFormPaso({ ...formPaso, urlVideo: e.target.value })}
            />
            <br />
            <label htmlFor="texto">Texto del paso:</label>
            <input
              type="text"
              id="texto"
              value={formPaso.texto}
              onChange={(e) => setFormPaso({ ...formPaso, texto: e.target.value })}
            />
            <br />
            <button type="button" onClick={handleAddPaso}>Añadir paso</button>
            <br /><br />

            <button type="submit">Crear tarea</button>
            <Link to="/admin" id="cancelar">Cancelar</Link>
          </form>

          <h3>Lista de Pasos</h3>
          <ul>
            {pasos.map((paso, index) => (
              <li key={index}>
                <strong>Paso {paso.orden}</strong>:
                <div>Imagen: {paso.imagen_paso ? paso.imagen_paso.name : 'No especificada'}</div>
                <div>Pictograma: {paso.pictograma ? paso.pictograma.name : 'No especificado'}</div>
                <div>Video: {paso.url_video || 'N/A'}</div>
                <div>Texto: {paso.texto}</div>

                <button onClick={() => movePasoUp(index)} disabled={index === 0}>Subir</button>
                <button onClick={() => movePasoDown(index)} disabled={index === pasos.length - 1}>Bajar</button>
                <button onClick={() => removePaso(index)}>Eliminar</button>
              </li>
            ))}
          </ul>
        </div>
      </main>
    </Layout>
  );
};

export default FormularioTarea;
