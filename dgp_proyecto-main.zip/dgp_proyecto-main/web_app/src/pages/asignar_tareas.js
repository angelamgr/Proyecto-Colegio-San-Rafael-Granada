import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import axios from 'axios';
import Layout from "../components/Layout";
import "../styles/asignar_tareas.css";

const AsignarTareas = () => {
  const [tareas, setTareas] = useState([]); 
  const [students, setStudents] = useState([]);
  const [selectedTarea, setSelectedTarea] = useState(null); // Tarea seleccionada
  const [selectedStudent, setSelectedStudent] = useState(null); // Estudiante seleccionado
  const navigate = useNavigate();

  useEffect(() => {
    // Función para obtener las tareas de la base de datos
    const fetchTareas = async () => {
      try {
        const token = localStorage.getItem('token');
        const response = await axios.get('http://localhost:8080/api/tasks', {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });

        const data = response.data;
        
        // Asegúrate de que `data` sea un arreglo
        setTareas(Array.isArray(data) ? data : [data]); // Si `data` no es un arreglo, lo convierte en uno.
      } catch (error) {
        console.error("Error al obtener las tareas:", error);
        if (error.response && error.response.data && error.response.data.message) {
          alert(error.response.data.message);
        } else {
          alert("Error al obtener las tareas");
        }
      }
    };
    
    fetchTareas();
  }, []);

  useEffect(() => {
    // Función para obtener los estudiantes
    const fetchStudents = async () => {
      try {
        const response = await fetch("http://localhost:8080/api/show_students");
        const data = await response.json();
        setStudents(data);
      } catch (error) {
        console.error("Error al obtener los estudiantes:", error);
      }
    }
    fetchStudents();
  }, []);

  // Función para manejar la selección de la tarea
  const handleTareaSelect = (tarea) => {
    console.log(tareas);
    const studentCards = document.querySelectorAll('.task-card');
    studentCards.forEach(card => {
      card.removeAttribute('selected');
    });
    const selectedCard = studentCards[tareas.indexOf(tarea)];
    if (selectedCard) {
      selectedCard.setAttribute('selected', 'true');
    }
    console.log("Tarea seleccionada:", tarea);
    setSelectedTarea(tarea);
  };

  // Función para manejar la selección del estudiante
  const handleStudentSelect = (student) => {
    console.log("Estudiante seleccionado:", student);
    const studentCards = document.querySelectorAll('.student-card');
    studentCards.forEach(card => {
      card.removeAttribute('selected');
    });
    const selectedCard = studentCards[students.indexOf(student)];
    if (selectedCard) {
      selectedCard.setAttribute('selected', 'true');
    }
        setSelectedStudent(student);
  };

  // Función para asignar la tarea al estudiante -> RELLENAR POR EL BACK
  const handleAssign = async () => {
    if (selectedTarea && selectedStudent) {
      console.log(`Asignar tarea ${selectedTarea.id_tarea} a estudiante ${selectedStudent.id}`);
      // Llamar a la API para asignar la tarea al estudiante
      try {
        const token = localStorage.getItem('token');
        const response = await axios.post('http://localhost:8080/api/assign_task', {
          id_tarea: selectedTarea.id_tarea,
          id_estudiante: selectedStudent.id_user
        }, {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });
        console.log("Tarea asignada al estudiante:", response.data);
        alert("Tarea asignada con éxito");
        navigate('/admin');
      } catch (error) {
        console.error("Error al asignar la tarea al estudiante:", error);
        if (error.response && error.response.data && error.response.data.message) {
          alert(error.response.data.message);
        } else {
          alert("Error al asignar la tarea al estudiante");
        }
      }

    }
  };
  return (
    <Layout>
      <div className="home">
        <h1>Listado de Tareas</h1>
        {tareas.map((tarea) => (
          <div key={tarea.id_tarea} className="task-card" onClick={() => handleTareaSelect(tarea)}>
            <img
              src={tarea.imagen_ident || 'default_photo_url'}
              alt={`Foto de ${tarea.nombre}`}
              className="profile-picture"
            />
            <h3>{tarea.nombre}</h3>
          </div>
        ))}


      </div>
      
      <div className="home">
        <h1>Lista de Estudiantes</h1>
        <div className="student-grid">
          {students.map((student) => (
            <div
              key={student.id}
              className="student-card"
              onClick={() => handleStudentSelect(student)}
            >
              <img
                src={student.profile_url}
                alt={`Foto de ${student.nombre}`}
                className="profile-picture"
              />
              <h3>{student.nombre}</h3>
            </div>
          ))}
        </div>
      </div>
      
      {selectedTarea && selectedStudent && (
        <button className="assign-button" onClick={handleAssign}>
          Asignar Tarea
        </button>
      )}
      
    </Layout>
  );
} 

export default AsignarTareas;