import React from 'react';
import Layout from '../components/Layout'
import Menuses from '../components/Menuses';
import '../styles/AdminContent.css';

const AdminContent = () => {
    return (
        <Layout>
            <h2>Admin Dashboard</h2>
            <Menuses />
        </Layout>
    );
};

export default AdminContent;
