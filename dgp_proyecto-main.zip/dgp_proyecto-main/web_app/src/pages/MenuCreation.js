// src/pages/MenuCreation.js
import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import useAxios from '../axiosConfig';
import '../styles/MenuCreation.css';
import Layout from '../components/Layout';

const MenuCreation = () => {
    const axios = useAxios();
    const [formData, setFormData] = useState({
        nombre: '',
        imagen: null,  // Añadimos un estado para la imagen
    });
    const navigate = useNavigate();

    // Controlador de cambio de entrada
    const handleImageChange = (e) => {
        const { name, value, files } = e.target;
        if (name === 'imagen') {
            setFormData((prevData) => ({
                ...prevData,
                [name]: files[0],  // Almacenamos el archivo de la imagen
            }));
        } else {
            setFormData((prevData) => ({
                ...prevData,
                [name]: value
            }));
        }
    };

    // Controlador de envío del formulario
    const handleSubmit = async (event) => {
        event.preventDefault();
        
        const formDataToSend = new FormData();
        formDataToSend.append('nombre', formData.nombre);
        
        if (formData.imagen) {
            formDataToSend.append('imagen', formData.imagen);  // Agregar la imagen
        }

        try {
            // Enviar los datos del formulario
            await axios.post('http://localhost:8080/api/add_menu', formDataToSend, {
                headers: {
                    'Content-Type': 'multipart/form-data',  // Aseguramos que se maneje como multipart/form-data
                }
            });
            
            // Si el menú se añade correctamente, se redirige al administrador
            alert('Menú añadido correctamente');
            navigate('/admin');
        } catch (error) {
            console.error('Error al añadir menú:', error);
            alert('Error al añadir menú. Verifica los datos.');
        }
    };

    // Verificación de validez de campos del formulario
    const isFormValid = formData.nombre;

    return (
        <Layout>
            <div className="menuCreation">
                <h1 id="titulo-form"> Añadir Menú </h1>
                <form id="añadirMenu" onSubmit={handleSubmit}>
                    <label htmlFor="nombre">Nombre del Menú:</label>
                    <input 
                        type="text" 
                        id="nombre" 
                        name="nombre" 
                        value={formData.nombre} 
                        onChange={handleImageChange} 
                        required 
                    />

                    <label htmlFor="imagen">Imagen del Menú:</label>
                    <input 
                        type="file" 
                        id="imagen" 
                        name="imagen" 
                        accept="image/*" 
                        onChange={handleImageChange} 
                    />

                    <button type="submit" disabled={!isFormValid}>Añadir</button>
                    <Link to="/admin" id="cancelar">Cancelar</Link>
                </form>
            </div>
        </Layout>
    );
};

export default MenuCreation;
