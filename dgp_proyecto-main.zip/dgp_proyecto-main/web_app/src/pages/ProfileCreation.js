import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import useAxios from '../axiosConfig';
import '../styles/ProfileCreation.css';
import Layout from '../components/Layout';

const ProfileCreation = () => {
    const axios = useAxios();
    const [formData, setFormData] = useState({
        nombre: '',
        usuario: '',
        contrasena: 'nopass',
        contrasenaDistractores: [],
        opciones: '',
        profileImage: null,
    });
    const [imagePreview, setImagePreview] = useState(null);
    const navigate = useNavigate();
    const opciones = ['Texto', 'Imagenes', 'Pictogramas', 'Imagen+Texto', 'Pictogramas+Texto'];
    const [showPassword, setShowPassword] = useState(false);
    const [distractors, setDistractors] = useState([]);
    const [realPasswords, setRealPasswords] = useState([]);

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData((prevData) => ({
            ...prevData,
            [name]: value
        }));
    };

    const handleDistractorFileChange = (e, index) => {
        const file = e.target.files[0];
        const updatedDistractors = [...distractors];
        updatedDistractors[index] = { id: index, file: URL.createObjectURL(file), originalFile: file };
        setDistractors(updatedDistractors);
    };

    const handleImageChange = (e) => {
        const file = e.target.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onloadend = () => {
                setFormData((prevData) => ({
                    ...prevData,
                    profileImage: file
                }));
                setImagePreview(reader.result);
            };
            reader.readAsDataURL(file);
        }
    };

    const handleSubmit = async (event) => {
        event.preventDefault();


        const dataToSend = new FormData();
        dataToSend.append('nombre', formData.nombre);
        dataToSend.append('usuario', formData.usuario);
        dataToSend.append('pwd', formData.contrasena);
        distractors.forEach((distractor) => {
            dataToSend.append('distractors', distractor.originalFile);
        });
        dataToSend.append('pwd_distractores_real', JSON.stringify(realPasswords));
        dataToSend.append('prefe_view', formData.opciones);

        if (formData.profileImage) {
            dataToSend.append('profileImage', formData.profileImage);
        }

        try {
            await axios.post('http://localhost:8080/api/add_student', dataToSend, {
                headers: {
                    'Content-Type': 'multipart/form-data',
                    Authorization: `Bearer ${localStorage.getItem('token')}`,
                }
            });
            alert('Estudiante añadido correctamente');
            navigate('/admin');
        } catch (error) {
            // Verifica si el error tiene una respuesta del servidor
            const errorMessage = error.response
                ? error.response.data.message || "Error desconocido en el servidor"
                : error.message || "Error al realizar la solicitud";
        
            console.error('Error al añadir estudiante:', errorMessage);
            alert('Error al añadir estudiante:' + errorMessage);
        }
        
    };

    const addDistractor = () => {
        setDistractors([...distractors, { id: distractors.length, file: null, originalFile: null }]);
    };

    const handleRemoveDistractor = (index) => {
        const updatedDistractors = distractors.filter((_, i) => i !== index);
        setDistractors(updatedDistractors);
    };
    

    const renderPasswordField = () => (
        <div className="password-field">
            <label htmlFor="contrasena">Contraseña:</label>
            <input
                type={showPassword ? "text" : "password"}
                id="contrasena"
                name="contrasena"
                value={formData.contrasena}
                onChange={handleChange}
                required
                aria-label="Contraseña"
            />
            <button type="button" onClick={() => setShowPassword(!showPassword)}>
                {(showPassword ? "Ocultar " : "Mostrar ") + "Contraseña"}
            </button>
        </div>
    );
    const renderDistractorFields = () => (
        <div className="distractor-fields">
            {distractors.map((distractor, index) => (
                <div key={`distractor-${distractor.id}`} className="distractor-field">
                    <div className="distractor-row">
                        <label htmlFor={`distractor${distractor.id}`}>Seleccione distractor {index + 1}</label>
                        <input
                            type="file"
                            id={`distractor${distractor.id}`}
                            name={`distractor${distractor.id}`}
                            accept="image/*"
                            onChange={(e) => handleDistractorFileChange(e, index)}
                            required
                            aria-label={`Distractor ${index + 1}`}
                        />
                        <button type="button" onClick={() => handleRemoveDistractor(index)} className="remove-distractor-button">
                            Eliminar
                        </button>
                    </div>
                </div>
            ))}
            <button type="button" onClick={addDistractor} className="add-distractor-button">
                Añadir distractor
            </button>
        </div>
    );
    

    const renderRealDistractorSelect = () => (
        <div className="real-distractor-select">
            <div className="real-distractor-select-title">
                <label htmlFor="opciones">Pulse cada imagen en un orden para establecer contraseña (max. 3): </label>
            </div>
            <div className="real-distractor-select-items">
                {distractors.map((distractor, index) => (
                    distractor.file && (
                        <div key={`real-distractor-${distractor.id}`} className="real-select">
                            <div 
                                className={`real-select-row ${realPasswords.includes(index) ? 'selected' : ''}`}
                                onClick={() => toggleRealPasswordSelection(index)}
                                style={{ cursor: 'pointer' }} 
                            >
                                <img
                                    src={distractor.file}
                                    alt={`Distractor ${index + 1}`}
                                    className="image-preview"
                                    style={{
                                        width: '60px', height: '60px', objectFit: 'cover',
                                        border: realPasswords.includes(index) ? '3px solid blue' : 'none', // Resalta la imagen seleccionada
                                    }}
                                />
                                {realPasswords.includes(index) && (
                                    <span className="selected-order">
                                        {realPasswords.indexOf(index) + 1} {/* Indica el orden */}
                                    </span>
                                )}
                            </div>
                        </div>
                    )
                ))}
            </div>
        </div>
    );
    
    
    const toggleRealPasswordSelection = (index) => {
        setRealPasswords((prev) => {
            if (prev.includes(index)) {
                return prev.filter((i) => i !== index);
            } else {
                return [...prev, index];
            }
        });
    };
    
    

    //
    //const isFormValid = formData.nombre && formData.usuario && formData.opciones && realPasswords.length > 0;


    return (
        <Layout>
            <div className="profileCreation">
                <h1 id="titulo-form">Alta de Estudiante</h1>
                <form id="creacion-perfiles" onSubmit={handleSubmit}>
                    <label htmlFor="nombre">Nombre del estudiante:</label>
                    <input
                        type="text"
                        id="nombre"
                        name="nombre"
                        value={formData.nombre}
                        onChange={handleChange}
                        required
                        aria-label="Nombre del estudiante"
                    />

                    <label htmlFor="usuario">Usuario:</label>
                    <input
                        type="text"
                        id="usuario"
                        name="usuario"
                        value={formData.usuario}
                        onChange={handleChange}
                        required
                        aria-label="Usuario"
                    />

                    <label htmlFor="profileImage">Imagen de Perfil (opcional)</label>
                    <p>Debe ser un archivo jpg o png</p>
                    <input
                        type="file"
                        id="profileImage"
                        name="profileImage"
                        accept="image/*"
                        onChange={handleImageChange}
                        aria-label="Imagen de Perfil"
                    />

                    {imagePreview && (
                        <div className="image-preview-container">
                            <h3>Vista previa de la imagen</h3>
                            <img
                                src={imagePreview}
                                alt="Vista previa de la imagen"
                                className="image-preview"
                            />
                        </div>
                    )}

                    <label htmlFor="opciones">Elige una opción de visualización:</label>
                    <select
                        id="opciones"
                        name="opciones"
                        value={formData.opciones}
                        onChange={handleChange}
                        required
                        aria-label="Elige una opción de visualización"
                    >
                        <option value="" disabled hidden>Selecciona una opción</option>
                        {opciones.map((opcion) => (
                            <option key={opcion} value={opcion}>
                                {opcion}
                            </option>
                        ))}
                    </select>

                    {/* Condicional rendering based on selected option */}


                    {(formData.opciones === 'Texto' || ['Imagen+Texto', 'Pictogramas+Texto'].includes(formData.opciones)) &&
                        renderPasswordField()}
                    {(['Imagenes', 'Pictogramas', 'Imagen+Texto', 'Pictogramas+Texto'].includes(formData.opciones)) &&
                        <>
                            {renderDistractorFields()}
                            {renderRealDistractorSelect()}
                        </>
                    }



                    <button type="submit" >
                        Registrar
                    </button>
                    <Link to="/admin" id="cancelar">Cancelar</Link>
                </form>
            </div>
        </Layout>
    );
};

export default ProfileCreation;
