import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import Layout from "../components/Layout";
import "../styles/Home.css";

const Home = () => {
  const [students, setStudents] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    // Función para obtener los estudiantes
    const fetchStudents = async () => {
      try {
        const response = await fetch("http://localhost:8080/api/show_students");
        const data = await response.json();
        setStudents(data);
      } catch (error) {
        console.error("Error al obtener los estudiantes:", error);
      }
    }
    fetchStudents();
  }, []);

  const handleCardClick = (student) => {
    navigate("/login_student", { state: student });
  };

  return (
    <Layout>
    <div className="home">
      <h1>Lista de Estudiantes</h1>
      <div className="student-grid">
        {students.map((student) => (
          <div
            key={student.id}
            className="student-card"
            onClick={() => handleCardClick(student)}
          >
            <img
              src={student.profile_url}
              alt={`Foto de ${student.nombre}`}
              className="profile-picture"
            />
            <h3>{student.nombre}</h3>
          </div>
        ))}
      </div>
    </div>
    </Layout>
  );
};

export default Home;
