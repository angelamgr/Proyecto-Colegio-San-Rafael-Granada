import React, { useState, useContext } from 'react';
import axios from 'axios';
import {jwtDecode} from 'jwt-decode';
import { AppContext } from '../AppContext'; 
import '../styles/LoginAdmin.css';
import { useNavigate } from 'react-router-dom';
import Layout from '../components/Layout';

const LoginAdmin = () => {
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const [errorMessage, setErrorMessage] = useState('');
    const { setUserData } = useContext(AppContext); 
    const navigate = useNavigate(); 
    
    const handleSubmit = async (event) => {
        event.preventDefault();
        setErrorMessage('');
        try {
            const response = await axios.post('http://localhost:8080/api/auth', { username, password });
            const { token } = response.data;

            // Decodificar token para obtener username y rol
            const decoded = jwtDecode(token);
            const { username: decodedUsername, id_rol: id_rol } = decoded;

            // Actualizar userData en AppContext
            setUserData({
                token, 
                username: decodedUsername,
                userRole: id_rol === 1 ? 'admin' : 'user',
                profileImage: response.data.image ? response.data.image : null,
                data: {} 
            });

            console.log('Inicio de sesión exitoso');
            // Navegar según el rol
            navigate('/admin');
        } catch (error) {
            console.error('Error al iniciar sesión:', error);
            setErrorMessage('Error al iniciar sesión. Por favor, verifica tus credenciales.');
        }
    };

    return (
        <Layout>
            <div className="login_admin">
                <h2>Admin Login</h2>
                {errorMessage && <p style={{ color: 'red' }}>{errorMessage}</p>}
                <form onSubmit={handleSubmit}>
                    <input
                        type="text"
                        name="username"
                        placeholder="Username"
                        value={username}
                        onChange={(e) => setUsername(e.target.value)}
                        required
                    />
                    <input
                        type="password"
                        name="password"
                        placeholder="Password"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        required
                    />
                    <button type="submit">Login</button>
                    <button type="button" onClick={() => navigate('/')}>Cancelar</button>
                    <a id="forgot_passwd" href="/">Forgot password?</a>
                </form> 
            </div>
        </Layout>
    );
};

export default LoginAdmin;
