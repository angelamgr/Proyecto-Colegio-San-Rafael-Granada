import React, { useContext, useEffect, useState } from "react";
import axios from "axios";
import Layout from "../components/Layout";
import LogoutButton from "../components/LogoutButton";
import { AppContext } from "../AppContext";
import "../styles/agenda.css"; // Asegúrate de que este archivo CSS se importe

const UserContent = () => {
  const [asignacion, setAsignacion] = useState([]);
  const [tareasEstado, setTareasEstado] = useState({});
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const { userData } = useContext(AppContext);

  useEffect(() => {
    const fetchAsignacion = async () => {
      try {
        const token = localStorage.getItem("token");
        let identificador = userData.id_student;
        const response = await axios.get(`http://localhost:8080/api/tasks/${identificador}`, {
          headers: {
            Authorization: `Bearer ${localStorage.getItem("token")}`,
          },
        });

        const data = response.data;
        setAsignacion(Array.isArray(data) ? data : [data]);

        const estadoInicial = {};
        (Array.isArray(data) ? data : [data]).forEach((tarea) => {
          estadoInicial[tarea.id] = false;
        });
        setTareasEstado(estadoInicial);
      } catch (error) {
        console.error("Error al obtener las asignaciones del estudiante:", error);
        setError(
          error.response?.data?.message || "Error al obtener las tareas"
        );
      } finally {
        setLoading(false);
      }
    };

    fetchAsignacion();
  }, [userData.id_student]);

  const manejarCheckbox = (id) => {
    setTareasEstado((prevEstado) => ({
      ...prevEstado,
      [id]: !prevEstado[id],
    }));
  };

  return (
    <Layout>
      <h1 className="user-content-header">Agenda del Estudiante {userData.username }</h1>
      {loading ? (
        <p>Cargando tareas...</p>
      ) : error ? (
        <p className="error">{error}</p>
      ) : (
        <ul className="user-content-tareas-lista">
          {asignacion.length > 0 ? (
            asignacion.map((tarea, index) => (
              <li key={index} className="tarea-item">
                <div className="tarea-contenido">
                  <img className="tarea-imagen"
                    src={tarea.imagen_ident}
                    alt={`Imagen de ${tarea.nombre}`}
                  />
                  <div>
                    <h2>{tarea.nombre} </h2>
                  </div>
                  <div className="tarea-checkbox-wrapper">
                    <input className="tarea-checkbox"
                      type="checkbox"
                      checked={tareasEstado[tarea.id] || false}
                      onChange={() => manejarCheckbox(tarea.id)}
                    />
                    <label className="checkbox-label">
                      {tareasEstado[tarea.id] ? "Realizada" : "Pendiente"}
                    </label>
                  </div>
                </div>
              </li>
            ))
          ) : (
            <p>No hay tareas asignadas</p>
          )}
        </ul>
      )}
      <LogoutButton/>
    </Layout>
  );
};

export default UserContent;
