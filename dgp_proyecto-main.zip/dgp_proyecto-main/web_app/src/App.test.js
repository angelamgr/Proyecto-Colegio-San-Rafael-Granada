import React from "react";
import { render, screen, fireEvent } from "@testing-library/react";
import App from "./App";

test("Ver si se renderiza el componente App", () => {
  // Renderizamos el componente en la ruta raíz
  render(<App />);
  // Verificamos si el componente se renderizó correctamente
  expect(screen.getByText("AutonoMe")).toBeInTheDocument();
});

test("Debe mostrar el botón 'Acceder' al hacer clic en la imagen de perfil", () => {
  // Renderiza el componente App (o el que contiene el header con la imagen de perfil)
  render(<App />);

  // Encuentra la imagen del perfil de administrador utilizando el texto alternativo (alt)
  const profileImage = screen.getByAltText(/admin profile/i);

  // Verifica que el botón "Acceder" no está en el DOM inicialmente
  expect(screen.queryByRole("button", { name: /acceder/i })).toBeNull();

  // Simula un clic en la imagen del perfil
  fireEvent.click(profileImage);

  // Verifica que el botón "Acceder" aparece después del clic
  const accederButton = screen.getByRole("button", { name: /acceder/i });
  expect(accederButton).toBeInTheDocument();
});