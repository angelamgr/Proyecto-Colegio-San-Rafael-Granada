import React, { useContext, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate, useNavigate } from 'react-router-dom';
import { AppProvider, AppContext } from './AppContext';
import LoginAdmin from './pages/LoginAdmin';
import AdminContent from './pages/AdminContent';
import FormularioTarea from './pages/tarea_pasos';
import UserContent from './pages/UserContent';
import ProfileCreation from './pages/ProfileCreation';
import MenuCreation from './pages/MenuCreation';
import LoginStudent from './pages/LoginStudent';
import Home from './pages/Home';
import AsignarTareas from './pages/asignar_tareas';

const App = () => {
    return (
        <AppProvider>
            <Router>
                <Routes>
                    <Route path="/" element={<Home />} />
                    <Route path="/login" element={<LoginRoute />} />
                    <Route path="/login_student" element={<LoginStudent />} />
                    <Route path="/pasos" element={<TareaPasos />} />
                    <Route path="/admin" element={<PrivateRoute component={AdminContent} requiredRole="admin" />} />
                    <Route path="/user" element={<PrivateRoute component={UserContent} requiredRole="user" />} />
                    <Route path="/admin/add_student" element={<PrivateRoute component={ProfileCreation} requiredRole="admin" />} />
                    <Route path="/admin/add_menu" element={<PrivateRoute component={MenuCreation} requiredRole="admin" />} />
                    <Route path="/admin/add_task" element={<PrivateRoute component={FormularioTarea} requiredRole="admin" />} />
                    <Route path="/admin/assign_task" element={<PrivateRoute component={AsignarTareas} requiredRole="admin"/>} />
                    {/* Otras rutas protegidas aquí */}
                </Routes>
            </Router>
        </AppProvider>
    );
};

// Función para verificar si un token JWT ha expirado
const isTokenExpired = (token) => {
    try {
        const payload = JSON.parse(atob(token.split('.')[1]));
        if (payload.exp < Date.now() / 1000) {
            return true;
        } else{
            localStorage.removeItem('userData');
            return false;
        }
    } catch (error) {
        console.error('Error al verificar la expiración del token:', error);
        return true;
    }
};

// Componente de ruta protegida que redirige a la página de login si el usuario no está autenticado
const PrivateRoute = ({ component: Component, requiredRole }) => {
    const { userData } = useContext(AppContext);

    const isAuthenticated = userData.token && !isTokenExpired(userData.token);
    const hasRequiredRole = userData.userRole === requiredRole;

    if (isAuthenticated && hasRequiredRole) {
        return <Component />;
    }

    // Si el usuario no está autenticado o el token ha expirado redirigir a la página de inicio
    if (isAuthenticated) {
        // Si el usuario tiene un token válido pero el rol no coincide
        return userData.userRole === 'admin' ? <Navigate to="/admin" /> : <Navigate to="/user" />;
    }

    // Si el usuario no está autenticado o el token ha expirado redirigir a la página de inicio
    if (!isAuthenticated) {
        return <Navigate to="/" />;
    }
};

// Componente de ruta de login que redirige a la página de inicio si el usuario ya está autenticado
const LoginRoute = () => {
    const { userData } = useContext(AppContext);
    const navigate = useNavigate();

    useEffect(() => {
        if (userData.token) {
            if (userData.userRole === 'admin' && !isTokenExpired(userData.token)) {
                navigate('/admin', { replace: true });
            } else if (userData.userRole === 'user' && !isTokenExpired(userData.token)) {
                navigate('/user', { replace: true });
            }
        }
    }, [userData, navigate]);

    return <LoginAdmin />;
};

const TareaPasos = () => {
    const { userData } = useContext(AppContext);
    const navigate = useNavigate();

    useEffect(() => {
        if (userData.token) {
            if (userData.userRole === 'admin' && !isTokenExpired(userData.token)) {
                navigate('/pasos', { replace: true });
            } else if (userData.userRole === 'user' && !isTokenExpired(userData.token)) {
                navigate('/user', { replace: true });
            }
        }
    }, [userData, navigate]);

    return <FormularioTarea />;
};

export default App;