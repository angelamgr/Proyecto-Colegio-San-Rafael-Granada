// axiosConfig.js
import axios from 'axios';
import { useContext } from 'react';
import { AppContext } from './AppContext';

const useAxios = () => {
    const { userData } = useContext(AppContext);

    const instance = axios.create({
        baseURL: 'http://localhost:8080/api',
    });

    instance.interceptors.request.use(
        (config) => {
            const token = userData.token;
            if (token && token !== '0') {
                config.headers.Authorization = `Bearer ${token}`;
            }
            return config;
        },
        (error) => {
            return Promise.reject(error);
        }
    );

    return instance;
};

export default useAxios;
