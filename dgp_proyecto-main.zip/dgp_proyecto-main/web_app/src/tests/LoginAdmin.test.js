import React from 'react';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import LoginAdmin from '../pages/LoginAdmin';
import { BrowserRouter as Router } from 'react-router-dom';
import { AppContext } from '../AppContext';
import axios from 'axios';
import { jwtDecode } from 'jwt-decode';

// Mock de axios para simular peticiones HTTP en las pruebas
jest.mock('axios');

// Mock del contexto de la aplicación para simular el estado global de la aplicación
const mockSetUserData = jest.fn();
const mockNavigate = jest.fn();

// Mock de useNavigate para evitar errores en las pruebas de navegación con React Router DOM
jest.mock('react-router-dom', () => ({
  ...jest.requireActual('react-router-dom'),
  useNavigate: () => mockNavigate,  // Asegúrate de mockear correctamente useNavigate
}));

// Mock de jwtDecode para simular la decodificación del JWT
jest.mock('jwt-decode', () => ({
  jwtDecode: jest.fn(),
}));

describe('Tests del LoginAdmin', () => {
  const mockUserData = {
    token: '',
    username: '',
    userRole: '',  // Valor predeterminado para evitar el error
    data: {},
  };

  beforeEach(() => {
    mockSetUserData.mockClear();
    mockNavigate.mockClear();
    jwtDecode.mockClear(); // Asegúrate de limpiar el mock de jwtDecode antes de cada prueba
  });

  test('Debe renderizar el formulario de inicio de sesión', () => {
    render(
      <Router>
        <AppContext.Provider value={{ userData: mockUserData, setUserData: mockSetUserData }}>
          <LoginAdmin />
        </AppContext.Provider>
      </Router>
    );

    // Verifica si el título y los elementos del formulario están en el DOM
    expect(screen.getByText('Admin Login')).toBeInTheDocument();
    expect(screen.getByPlaceholderText('Username')).toBeInTheDocument();
    expect(screen.getByPlaceholderText('Password')).toBeInTheDocument();
    expect(screen.getByRole('button', { name: /login/i })).toBeInTheDocument();
  });

  test('Debe manejar un inicio de sesión exitoso', async () => {
    // Simula una respuesta exitosa de axios con un token falso
    axios.post.mockResolvedValue({
      data: {
        token: 'fake-jwt-token',
      },
    });

    // Simula la decodificación del JWT
    jwtDecode.mockReturnValue({
      username: 'admin',
      userRole: 1,  // Simula que el rol es "admin"
    });

    render(
      <Router>
        <AppContext.Provider value={{ userData: mockUserData, setUserData: mockSetUserData }}>
          <LoginAdmin />
        </AppContext.Provider>
      </Router>
    );

    // Simula la escritura en los campos de texto
    fireEvent.change(screen.getByPlaceholderText('Username'), { target: { value: 'admin' } });
    fireEvent.change(screen.getByPlaceholderText('Password'), { target: { value: 'rightPassword' } });

    // Simula el envío del formulario (clic en el botón Login)
    fireEvent.click(screen.getByRole('button', { name: /login/i }));

    // Espera que la respuesta asincrónica se haya procesado
    await waitFor(() => {
      // Verifica que la función navigate haya sido llamada con la ruta esperada
      expect(mockNavigate).toHaveBeenCalledWith('/admin');
      // Verifica que la función setUserData haya sido llamada con los valores correctos
      expect(mockSetUserData).toHaveBeenCalledWith({
        token: 'fake-jwt-token',
        username: 'admin',
        userRole: 'admin',
        profileImage: null,
        data: {},
      });
    });
  });

  test('Debe manejar un error en el inicio de sesión', async () => {
    // Simula un error en la respuesta de axios
    axios.post.mockRejectedValue(new Error('Error al iniciar sesión'));

    render(
      <Router>
        <AppContext.Provider value={{ userData: mockUserData, setUserData: mockSetUserData }}>
          <LoginAdmin />
        </AppContext.Provider>
      </Router>
    );

    // Simula la escritura en los campos de texto
    fireEvent.change(screen.getByPlaceholderText('Username'), { target: { value: 'admin' } });
    fireEvent.change(screen.getByPlaceholderText('Password'), { target: { value: 'wrongpassword' } });

    // Simula el envío del formulario
    fireEvent.click(screen.getByRole('button', { name: /login/i }));

    // Espera a que el error se maneje
    await waitFor(() => {
      // Verifica que el mensaje de error esté en el DOM
      expect(screen.getByText('Error al iniciar sesión. Por favor, verifica tus credenciales.')).toBeInTheDocument();
    });
  });

  test('Debe navegar a la página de inicio cuando se hace clic en "Cancelar"', () => {
    render(
      <Router>
        <AppContext.Provider value={{ userData: mockUserData, setUserData: mockSetUserData }}>
          <LoginAdmin />
        </AppContext.Provider>
      </Router>
    );

    // Simula el clic en el botón "Cancelar"
    fireEvent.click(screen.getByRole('button', { name: /cancelar/i }));

    // Verifica que la función navigate haya sido llamada con la ruta esperada
    expect(mockNavigate).toHaveBeenCalledWith('/');
  });

  test('Debe mostrar un enlace "Forgot password?"', () => {
    render(
      <Router>
        <AppContext.Provider value={{ userData: mockUserData, setUserData: mockSetUserData }}>
          <LoginAdmin />
        </AppContext.Provider>
      </Router>
    );

    // Verifica que el enlace "Forgot password?" esté presente
    expect(screen.getByText('Forgot password?')).toBeInTheDocument();
  });
});
