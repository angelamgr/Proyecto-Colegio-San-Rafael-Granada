-- =========================
-- Borrar las tablas
-- =========================

SET FOREIGN_KEY_CHECKS = 0;

DROP TABLE IF EXISTS ASIGNACION;
DROP TABLE IF EXISTS PASOS;
DROP TABLE IF EXISTS TAREA_PASOS;
DROP TABLE IF EXISTS Estudiante;
DROP TABLE IF EXISTS Menu;
DROP TABLE IF EXISTS Usuario;
DROP TABLE IF EXISTS Imagen;
DROP TABLE IF EXISTS Rol;

SET FOREIGN_KEY_CHECKS = 1;

-- =========================
-- Crear las tablas
-- =========================

CREATE TABLE Imagen (
    id_img INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(46) NOT NULL,
    alt_text VARCHAR(255),  
    tipo ENUM('Imagen', 'Pictograma') NOT NULL
);

CREATE TABLE Rol (
    id_rol INT AUTO_INCREMENT PRIMARY KEY,
    tipo_rol VARCHAR(20) NOT NULL
);

CREATE TABLE Usuario (
    id_user INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(50) NOT NULL,
    usuario VARCHAR(30) NOT NULL UNIQUE,
    pwd VARCHAR(30) NOT NULL,
    id_img INT DEFAULT 1,
    id_rol INT,
    FOREIGN KEY (id_img) REFERENCES Imagen(id_img),
    FOREIGN KEY (id_rol) REFERENCES Rol(id_rol)
);

CREATE TABLE Estudiante (
    id_estudiante INT AUTO_INCREMENT PRIMARY KEY,
    pwd_distractores JSON NOT NULL,
    pwd_distractores_real JSON NOT NULL,
    prefe_view ENUM('Texto', 'Imagenes', 'Pictogramas', 'Imagen+Texto', 'Pictogramas+Texto'),
    FOREIGN KEY (id_estudiante) REFERENCES Usuario(id_user)
);

CREATE TABLE Menu (
    id_menu INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(30) NOT NULL,
    id_img INT,
    FOREIGN KEY (id_img) REFERENCES Imagen(id_img)
);

CREATE TABLE TAREA_PASOS (
    id_tarea INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    id_img INT,
    FOREIGN KEY (id_img) REFERENCES Imagen(id_img)
);

CREATE TABLE PASOS (
    id_paso INT AUTO_INCREMENT PRIMARY KEY,
    id_tarea INT NOT NULL,
    orden INT NOT NULL,
    url_video VARCHAR(255),
    texto TEXT,
    id_img INT,
    id_picto INT,
    FOREIGN KEY (id_img) REFERENCES Imagen(id_img),
    FOREIGN KEY (id_picto) REFERENCES Imagen(id_img),
    FOREIGN KEY (id_tarea) REFERENCES TAREA_PASOS(id_tarea)
);

CREATE TABLE ASIGNACION(
    id_asig INT AUTO_INCREMENT PRIMARY KEY,
    id_estudiante INT,
    id_tarea INT,
    estado ENUM('COMPLETA', 'PENDIENTE', 'EN PROCESO'),
    FOREIGN KEY (id_tarea) REFERENCES TAREA_PASOS(id_tarea),
    FOREIGN KEY (id_estudiante) REFERENCES Estudiante(id_estudiante)
);

-- =========================
-- Insertar datos iniciales
-- =========================

-- Insertar roles
INSERT INTO Rol (tipo_rol) VALUES ('Administrador'), ('Usuario'), ('Invitado');

-- Insertar imágenes
INSERT INTO Imagen (nombre, alt_text, tipo) VALUES 
('default.png', 'Imagen por defecto', 'Imagen'), 
('bear.png', 'Oso', 'Imagen'), 
('duck.png', 'Pato', 'Imagen'), 
('panda.png', 'Panda', 'Imagen'), 
('unicorn.png', 'Unicornio', 'Imagen'),
('food_salad.png', 'Ensalada', 'Imagen'), 
('food_burg.png', 'Hamburguesa', 'Imagen'), 
('food_veg.png', 'Comida Vegana', 'Imagen');

-- Insertar usuarios
INSERT INTO Usuario (nombre, usuario, pwd, id_img, id_rol) 
VALUES 
('Juan Perez', 'admin', 'admin', 1, 1),
('Eduardo Mendoza', 'eduardo', 'pwd123', 3, 2), 
('Clara Schuman', 'clara', 'pwd123', 2, 2),
('Frederic Chopin', 'frederic', 'pwd123', 4, 2),
('Barbara Strozzi', 'barbara', 'pwd123', 5, 2);

-- Insertar estudiantes
INSERT INTO Estudiante (id_estudiante, pwd_distractores, pwd_distractores_real, prefe_view) 
VALUES
(2, '["1", "2", "3", "4", "5", "6"]', '["2", "4", "5"]', 'Imagen+Texto'),  
(3, '["2", "3", "4", "6", "7", "8"]', '["3", "6", "7"]', 'Pictogramas'),  
(4, '["1", "5", "2", "6", "7", "8"]', '["5", "6", "2"]', 'Texto'),        
(5, '["4", "1", "3", "7", "5", "8"]', '["1", "3", "7"]', 'Imagenes');       

-- Insertar Menu
INSERT INTO Menu (nombre, id_img) VALUES
("Ensalada", 6),
("Hamburguesa", 7),
("Vegano", 8);
