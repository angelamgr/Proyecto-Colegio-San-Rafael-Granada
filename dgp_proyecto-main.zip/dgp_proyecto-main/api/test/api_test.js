import { before, describe, it } from "node:test";
import assert from "node:assert";
import http from "node:http";

const HOST = {
    URL: "localhost",
    PORT: 8080,
};

async function admin_setup() {
    const post_data = JSON.stringify({
        username: "admin",
        password: "admin",
    });

    const req_data = {
        hostname: HOST.URL,
        port: HOST.PORT,
        path: "/api/auth",
        method: "POST",
        headers: {
            "Content-Type": "application/json",
            "Content-Length": Buffer.byteLength(post_data),
        },
    };

    return new Promise((resolve, reject) => {
        const req = http.request(req_data, (res) => {
            let response_body = "";
            res.on("data", (chunk) => {
                response_body += chunk;
            });

            res.on("end", () => {
                try {
                    const body = JSON.parse(response_body);
                    const token = body.token;
                    resolve(token);
                } catch (err) {
                    reject(err);
                }
            });
        });

        req.on("error", (err) => reject(err));
        req.write(post_data);
        req.end();
    });
}

async function make_request(path, method = "GET", token = null, data = null) {
    const req_data = {
        hostname: HOST.URL,
        port: HOST.PORT,
        path,
        method,
        headers: {
            "Content-Type": "application/json",
        },
    };

    if (token) {
        req_data.headers.Authorization = `Bearer ${token}`;
    }
    if (data) {
        req_data.headers["Content-Length"] = Buffer.byteLength(data);
    }

    return new Promise((resolve, reject) => {
        const req = http.request(req_data, (res) => {
            let res_data = "";
            res.on("data", (chunk) => (res_data += chunk));
            res.on("end", () =>
                resolve({ statusCode: res.statusCode, body: res_data }),
            );
        });

        req.on("error", (err) => reject(err));

        if (data) {
            req.write(data);
        }
        req.end();
    });
}


describe("Student test", () => {
    let auth_token;
    let student_id;
    const student_data = JSON.stringify({
        nombre: "John Doe",
        usuario: "johndoe",
        pwd: "securepassword",
        pwd_distractores: "distractorpassword",
        prefe_view: "Texto",
        profileImage: null,
    });

    before(async () => {
        auth_token = await admin_setup();
    });

    it("Should get a valid token", () => {
        assert(auth_token.length > 0, "Token should not be empty");
    });

    it("Should add new user", async () => {
        const response = await make_request(
            "/api/add_student",
            "POST",
            auth_token,
            student_data
        );
        assert.strictEqual(response.statusCode, 200);
    });

    it("Should get a user id", async () => {
        const response = await make_request(
            "/api/student_id/johndoe",
            "GET",
            auth_token
        );
        assert.strictEqual(response.statusCode, 200);
        const body = JSON.parse(response.body);
        assert(body.id_estudiante);
        student_id = body.id_estudiante;
    });

    it("Should delete a user", async () => {
        const response = await make_request(
            `/api/delete_student/${student_id}`,
            "DELETE",
            auth_token
        );
        assert.strictEqual(response.statusCode, 200);
    });
});

