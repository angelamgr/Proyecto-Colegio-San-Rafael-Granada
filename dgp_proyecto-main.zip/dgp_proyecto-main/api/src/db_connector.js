const mariadb = require("mariadb");

class DBConnector {
    static instance = null;

    constructor() {
        if (DBConnector.instance) {
            return DBConnector.instance;
        }

        this.config = {
            host: process.env.DB_HOST || "db",
            user: process.env.DB_USER || "user",
            password: process.env.DB_PASSWORD || "user",
            database: process.env.DB_NAME || "app_dgp",
            connectionLimit: 5,
        };

        this.pool = mariadb.createPool(this.config);
        DBConnector.instance = this;
        this.connection = null;
        return this;
    }

    async transaction(callback) {
        let conn = null;
        try {
            conn = await this.pool.getConnection();
            await conn.beginTransaction();
            await callback(conn);
            await conn.commit();
        } catch (error) {
            console.log("Error en la transaccion: ", error);
            if (conn) {
                await conn.rollback();
                throw error;
            }
        } finally {
            if (conn) {
                conn.release();
            }
        }
    }

    async query(query, params = [], connection = null) {
        const conn = connection ? connection : await this.pool.getConnection();
        if (!conn) {
            throw new Error("No se ha establecido una conexión con la base de datos");
        }
        try {
            const rows = await conn.query(query, params);
            return rows;
        } finally {
            if (!connection && conn) {
                conn.release();
            }
        }
    }

    async connect() {
        try {
            if (!this.connection) {
                this.connection = await this.pool.getConnection();
                console.log("Conectado a la base de datos");
            }
            return this.connection;
        } catch (error) {
            console.error("Error al conectar a la base de datos:", error);
        }
    }

    async disconnect() {
        try {
            if (this.connection) {
                await this.connection.release();
                console.log("Conexión a la base de datos liberada");
                this.connection = null;
            }
        } catch (error) {
            console.error("Error al liberar la conexión de la base de datos:", error);
        }
    }

    async closePool() {
        try {
            await this.pool.end();
            console.log("Pool de conexiones cerrado");
        } catch (error) {
            console.error("Error al cerrar el pool de conexiones:", error);
        }
    }

    static getInstance() {
        if (!DBConnector.instance) {
            DBConnector.instance = new DBConnector();
        }
        return DBConnector.instance;
    }

    //Nota: guardamos contraseñas en texto plano? al menos podriamos usar hash
    async findUserByCredentials(username, password) {
        let connection;
        try {
            connection = await this.pool.getConnection();
            const query = "SELECT * FROM Usuario WHERE usuario = ? AND pwd = ?";
            const rows = await connection.query(query, [username, password]);

            return rows.length > 0 ? rows[0] : null;
        } catch (error) {
            console.error("Error al buscar el usuario en la base de datos:", error);
            throw error;
        } finally {
            //Esto no está muy claro.
            if (connection) connection.release();
        }
    }

    // Método para buscar un estudiante por su username
    async findUserByUsername(username) {
        let connection;
        try {
            connection = await this.pool.getConnection();
            const query = "SELECT * FROM Usuario WHERE usuario = ? AND id_rol = 2";
            const rows = await connection.query(query, [username]);

            return rows.length > 0 ? rows[0] : null;
        } catch (error) {
            console.error(
                "Error al buscar el estudiante en la base de datos:",
                error,
            );
            throw error;
        } finally {
            if (connection) connection.release();
        }
    }

    async updateUserProfileImage(id_user, imageUrl) {
        let connection;
        try {
            connection = await this.pool.getConnection();
            const query = "UPDATE Usuario SET imagen_iden = ? WHERE id_user = ?";
            await connection.query(query, [imageUrl, id_user]);
        } catch (error) {
            console.error(
                "Error al actualizar la foto de perfil del usuario:",
                error,
            );
            throw error;
        } finally {
            if (connection) connection.release();
        }
    }

    async deleteTaskWithStepsById(id_task) {
        let connection;
        try {
            connection = await this.pool.getConnection();
            await connection.beginTransaction();

            const deleteAsignationQuery = "DELETE FROM ASIGNACION WHERE id_tarea = ?";
            await connection.query(deleteAsignationQuery, [id_task]);

            const deleteStepsQuery = "DELETE FROM PASOS WHERE id_tarea = ?";
            await connection.query(deleteStepsQuery, [id_task]);

            const deleteTaskQuery = "DELETE FROM TAREA_PASOS WHERE id_tarea = ?";
            await connection.query(deleteTaskQuery, [id_task]);

            await connection.commit();
            console.log("Tarea y sus pasos eliminados correctamente");
        } catch (error) {
            if (connection) await connection.rollback();
            console.error("Error al eliminar la tarea y sus pasos:", error);
            throw error;
        } finally {
            if (connection) connection.release();
        }
    }
}

module.exports = DBConnector;
