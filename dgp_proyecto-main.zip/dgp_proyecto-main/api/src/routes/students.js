const addStudent = async (req, res, databaseConnector) => {
    try {
        await databaseConnector.transaction(async (conn) => {
            const { nombre, usuario, pwd, prefe_view } = req.body;
            const distractorFiles = req.files.distractors || [];
            const pwd_distractores_real = JSON.parse(req.body.pwd_distractores_real);


            // Verificar los campos requeridos
            if (
                !nombre ||
                !usuario ||
                !pwd ||
                !prefe_view ||
                (prefe_view !== "Texto" && distractorFiles.some(d => !d))
            ) {
                console.log("nombre:", nombre);
                console.log("usuario:", usuario);
                console.log("pwd:", pwd);
                console.log("prefe_view:", prefe_view);
                console.log("FILES:", req.files);
                throw new Error("Todos los campos son obligatorios.");
            }

            console.log("Distractores: ",distractorFiles);
            // Verificar si el usuario ya existe
            const queryUsuarioExistente = "SELECT * FROM Usuario WHERE usuario = ?";
            const existingUser = await databaseConnector.query(
                queryUsuarioExistente,
                [usuario],
                conn,
            );
            if (existingUser.length > 0) {
                throw new Error("El usuario ya existe");
            }

            // Insertar imagen de perfil
            let id_img = null;
            if (req.files.profileImage && req.files.profileImage.length > 0) {
                const profileImage = req.files.profileImage[0];
                const imageQuery = "INSERT INTO Imagen (nombre, tipo) VALUES (?, ?)";
                const imageType = profileImage.mimetype.startsWith("image/")
                    ? "Imagen"
                    : "Pictograma";
                const imageName = profileImage.filename;
                const result = await databaseConnector.query(
                    imageQuery,
                    [imageName, imageType],
                    conn,
                );
                id_img = result.insertId;
            }

            // Insertar imágenes de distractores
            let distractorIds = [];
            for (const distractor of distractorFiles) {
                console.log("Insertando distractor: ",distractor.filename);
                if (distractor) {
                    const distractorQuery = "INSERT INTO Imagen (nombre, tipo) VALUES (?, ?)";
                    const imageType = distractor.mimetype.startsWith("image/")
                        ? "Imagen"
                        : "Pictograma";
                    const imageName = distractor.filename;
                    const result = await databaseConnector.query(
                        distractorQuery,
                        [imageName, imageType],
                        conn,
                    );
                    // Convertir el BigInt a string antes de agregarlo a distractorIds
                    distractorIds.push(result.insertId.toString());
                    console.log("Img id: ",result.insertId," == ",distractor.filename);
                } else {
                    console.log(`No se recibió el distractor ${i + 1}`);
                }
            }

            //Preparar distractores correctos
            console.log("Ids reales: ",pwd_distractores_real);
            const correctDistractorIds = pwd_distractores_real.map(index => {
                return distractorIds[index]; // Usar el índice de pwd_distractores_real para seleccionar el distractor correcto
            });

            // Insertar Usuario
            const insertUserQuery = `
                INSERT INTO Usuario (nombre, usuario, pwd, id_img, id_rol) 
                VALUES (?, ?, ?, ?, ?)
            `;
            const insertParams = [nombre, usuario, pwd, id_img, 2]; // 2 es el rol de estudiante
            const result = await databaseConnector.query(
                insertUserQuery,
                insertParams,
                conn,
            );
            const userId = result.insertId;

            // Insertar Estudiante con distractores en JSON
            const insertStudentQuery = `
                INSERT INTO Estudiante (id_estudiante, pwd_distractores, pwd_distractores_real, prefe_view) 
                VALUES (?, ?, ?, ?)
            `;
            await databaseConnector.query(
                insertStudentQuery,
                [userId, JSON.stringify(distractorIds), JSON.stringify(correctDistractorIds), prefe_view],
                conn,
            );
        });

        res.status(200).json({ message: "Estudiante añadido correctamente." });
    } catch (error) {
        console.error("Error en la transacción:", error);
        res
            .status(500)
            .json({ message: error.message || "Error al añadir el estudiante." });
    }
};



const getStudentIdByUser = async (req, res, databaseConnector) => {
    try {
        const { usuario } = req.params; // Usamos 'usuario' porque es el campo que tiene el nombre de usuario
        const query =
            "SELECT id_estudiante FROM Estudiante WHERE id_estudiante IN (SELECT id_user FROM Usuario WHERE usuario = ?)";
        const resp = await databaseConnector.query(query, [usuario]);
        res.status(200).json(resp[0]);
    } catch (error) {
        res.status(500).json({
            message: error.message || "Error al obtener el ID del estudiante.",
        });
    }
};

const getStudents = async (req, res, databaseConnector) => {
    try {
        const query = `
        SELECT 
            Usuario.id_user, 
            Usuario.nombre, 
            Usuario.usuario, 
            Estudiante.pwd_distractores, 
            Estudiante.pwd_distractores_real, 
            Estudiante.prefe_view, 
            IFNULL(CONCAT('http://localhost:8080/images/', Imagen.nombre), '') AS profile_url
        FROM 
            Usuario
        JOIN 
            Estudiante ON Usuario.id_user = Estudiante.id_estudiante
        LEFT JOIN 
            Imagen ON Usuario.id_img = Imagen.id_img
        WHERE 
            Usuario.id_rol = 2;
    `;
        const students = await databaseConnector.query(query);
        return res.status(200).json(students);
    } catch (error) {
        console.error(error);
        return res
            .status(500)
            .json({ message: "Server: Error al consultar estudiantes" });
    }
};

const getStudentPwdDist = async (req, res, databaseConnector) => {
    const { usuario } = req.params;
    if (!usuario) {
        return res.status(400).json({ message: "Nombre de usuario no proporcionado." });
    }

    const query = `SELECT e.pwd_distractores
                   FROM Estudiante e
                   JOIN Usuario u ON e.id_estudiante = u.id_user
                   WHERE u.usuario = ?`;

    try {
        const result = await databaseConnector.query(query, [usuario]);

        if (result.length === 0) {
            return res.status(404).json({ message: "Estudiante no encontrado." });
        }
        console.log("Distractores para: ", usuario, " son ", result[0]);
        const pwd_distractores = result[0].pwd_distractores;
        if (pwd_distractores && pwd_distractores.length > 0) {
            const distractorQuery = `SELECT id_img,nombre, alt_text 
                                     FROM Imagen 
                                     WHERE id_img = ? `;

            let distractorResult = [];
            for (const img_id of pwd_distractores) {  
                const temp = await databaseConnector.query(distractorQuery, [img_id]);
                distractorResult.push(temp[0]); 
            }

           
            const imageData = distractorResult.map(distractor => ({
                id_img: distractor.id_img,
                nombre: distractor.nombre,
                alt_text: distractor.alt_text,
                url: `http://localhost:8080/images/${distractor.nombre}`
            }));

            console.log(imageData);  

            console.log("La respuesta para: ", usuario, " es ", imageData);
            return res.status(200).json({ images: imageData });
        } else {
            return res.status(404).json({ message: "No se encontraron distractores para este estudiante." });
        }

    } catch (error) {
        console.error("Error al obtener las imágenes distractoras:", error);
        return res.status(500).json({ message: "Error al obtener las imágenes distractoras." });
    }
};


const deleteStudent = async (req, res, databaseConnector) => {
    const { id_student } = req.params;

    if (!id_student) {
        return res
            .status(400)
            .json({ message: "El campo id_student es obligatorio." });
    }

    try {
        await databaseConnector.transaction(async (conn) => {
            const student_query = "DELETE FROM Estudiante WHERE id_estudiante = ?";
            const user_query = "DELETE FROM Usuario WHERE id_user = ?";
            await databaseConnector.query(student_query, [id_student], conn);
            await databaseConnector.query(user_query, [id_student], conn);
        });
        res.status(200).json({ message: "Estudiante eliminado." });
    } catch (error) {
        console.error("Error al eliminar menú:", error);
        res
            .status(500)
            .json({ message: error.message || "Error al borrar el estudiante." });
    }
};

const getStudent = async (req, res, databaseConnector) => {
    const { usuario } = req.params;  // Obtener el usuario desde los parámetros de la URL

    // Verificar si se pasó el usuario en la solicitud
    if (!usuario) {
        return res
            .status(400)
            .json({ message: "Usuario no proporcionado." });
    }

    try {
        // Consulta para obtener los datos del estudiante y su información asociada
        const query = `
            SELECT 
                u.id_user, 
                u.nombre AS usuario_nombre, 
                u.usuario, 
                u.pwd, 
                e.id_estudiante, 
                e.pwd_distractores, 
                e.pwd_distractores_real,
                e.prefe_view
            FROM 
                Usuario u
            JOIN 
                Estudiante e ON u.id_user = e.id_estudiante
            WHERE 
                u.usuario = ?
        `;

        // Realizar la consulta a la base de datos con el usuario proporcionado
        const [studentData] = await databaseConnector.query(query, [usuario]);

        // Si no se encuentra el estudiante
        if (!studentData) {
            return res
                .status(404)
                .json({ message: "Estudiante no encontrado." });
        }

        // Si se encuentra el estudiante, devolver la información
        res.status(200).json({ student: studentData });
    } catch (error) {
        console.error("Error al obtener los datos del estudiante:", error);
        res
            .status(500)
            .json({ message: error.message || "Error al obtener los datos del estudiante." });
    }
};


module.exports = {
    addStudent,
    getStudentIdByUser,
    getStudents,
    getStudentPwdDist,
    deleteStudent,
    getStudent
};
