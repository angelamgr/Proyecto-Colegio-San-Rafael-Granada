/* UPLOAD FILES */


/*Placeholder generado con chatgpt. REVISAR ANTES  */
const getTasks = async (req, res, databaseConnector) => {
    //console.log("Obteniendo tareas");
    try {
        const tasksQuery = `
            SELECT t.id_tarea, t.nombre, t.id_img AS imagen_ident, p.id_paso, p.orden, p.id_img AS url_imagen, p.url_video, p.texto
            FROM TAREA_PASOS t
            LEFT JOIN PASOS p ON t.id_tarea = p.id_tarea
        `;
        const imagesQuery = `
            SELECT id_img, IFNULL(CONCAT('http://localhost:8080/images/', nombre), '') AS nombre
            FROM Imagen
            WHERE id_img IN (SELECT id_img FROM TAREA_PASOS UNION SELECT id_img FROM PASOS)
        `;

        const images = await databaseConnector.query(imagesQuery);
        const imagesMap = images.reduce((acc, image) => {
            acc[image.id_img] = image.nombre;
            return acc;
        }, {});

        const tasks = await databaseConnector.query(tasksQuery);

        const formattedTasks = tasks.reduce((acc, task) => {
            if (!acc[task.id_tarea]) {
            acc[task.id_tarea] = {
                id_tarea: task.id_tarea,
                nombre: task.nombre,
                imagen_ident: imagesMap[task.imagen_ident] || null,
                pasos: []
            };
            }

            if (task.id_paso) {
            acc[task.id_tarea].pasos.push({
                id_paso: task.id_paso,
                orden: task.orden,
                url_imagen: imagesMap[task.url_imagen] || null,
                url_video: task.url_video,
                texto: task.texto
            });
            }

            return acc;
        }, {});


        const tasksArray = Object.values(formattedTasks);
        return res.status(200).json(tasksArray);
    } catch (error) {
        console.error('Error al obtener las tareas:', error);
        return res.status(500).json({ message: 'Error al obtener las tareas' });
    }
};


const addTask = async (req, res, databaseConnector) => {
    console.log("Guardando tarea");
    /**
     * 1. Verificar los campos
     * 2. Guardar la imagen identificativa y obtener su id_img
     * 3. Insertar la tarea en TAREA_PASOS y obtener su id_tarea
    **/
   let idTarea = null;

    try {
        // Ejecutar la transacción
        const { nombre } = req.body;
        // 1. Verificar que los campos necesarios están presentes

        if (!nombre || !req.file) {
            return res.status(400).json({ message: 'Se requiere un nombre y una imagen identificativa.' });
        }

        // 2. Guardar la imagen identificativa en la tabla Imagen
        const imageName = req.file.filename;  // Accede al nombre de la imagen cargada

        // Verificar si la tarea ya existe en la base de datos
        const checkTaskQuery = `SELECT COUNT(*) AS count FROM TAREA_PASOS WHERE nombre = ?`;
        const taskCheck = await databaseConnector.query(checkTaskQuery, [nombre]);

        if (taskCheck[0].count > 0) {
            return res.status(400).json({ message: 'Una tarea con el mismo nombre ya existe en la base de datos.' });
        }
        
        await databaseConnector.transaction(async (conn) => {
            const insertImageQuery = `INSERT INTO Imagen (nombre, tipo) VALUES (?, 'Imagen')`;
            const resultImg = await databaseConnector.query(insertImageQuery, [imageName]);
            const idImgIdent = resultImg.insertId;

            // 3. Insertar la tarea en la tabla TAREA_PASOS
            const insertTaskQuery = `INSERT INTO TAREA_PASOS (nombre, id_img) VALUES (?, ?)`;
            const resultTask = await databaseConnector.query(insertTaskQuery, [nombre, idImgIdent]);
            idTarea = resultTask.insertId;
        });

        console.log("Tarea creada con id: ", idTarea);

        return res.status(200).json({
            message: 'Tarea creada exitosamente',
            idTarea: idTarea.toString()
        });
    } catch (error) {
        console.error('Error al crear la tarea o en la transacción:', error);
        return res.status(500).json({ message: 'Error al agregar tarea.', error: error.message });
    }
};



const saveImage = async (file, type, databaseConnector) => {
    const allowedFileTypes = ['image/jpeg', 'image/png', 'image/gif'];

    if (!allowedFileTypes.includes(file.mimetype)) {
        throw new Error(`El archivo del ${type} debe ser una imagen .jpg, .png o .gif`);
    }

    const filePath = file.filename;
    const insertImageQuery = `INSERT INTO Imagen (nombre, tipo) VALUES (?, ?)`;
    const result = await databaseConnector.query(insertImageQuery, [filePath, type]);
    return result.insertId;
};

const addStep = async (req, res, databaseConnector) => {
    console.log("Guardando paso");

    try {
        const { id_tarea, orden, url_video, texto } = req.body;
        const { stepImage, pictoImage } = req.files; 

        if (!id_tarea || !orden || !texto) {
            return res.status(400).json({ message: 'Faltan campos obligatorios: id_tarea, orden o texto.' });
        }
        await databaseConnector.transaction(async (conn) => {
            let idImgPaso = null;
            if (stepImage && stepImage[0]) {
                idImgPaso = await saveImage(stepImage[0], 'Imagen', databaseConnector);
            }

            let idPicto = null;
            if (pictoImage && pictoImage[0]) {
                idPicto = await saveImage(pictoImage[0], 'Pictograma', databaseConnector);
            }

            const insertStepQuery = `
                INSERT INTO PASOS (id_tarea, orden, url_video, texto, id_img, id_picto)
                VALUES (?, ?, ?, ?, ?, ?)`;
            
            await databaseConnector.query(insertStepQuery, [
                id_tarea, orden, url_video || null, texto, idImgPaso || null, idPicto || null
            ]);
        });

        return res.status(201).json({
            message: 'Paso creado exitosamente'
        });

    } catch (error) {
        console.error('Error en la transacción de agregar paso:', error); 
        return res.status(500).json({ message: 'Error al agregar paso. Inténtelo de nuevo.', error: error.message });
    }
};

const assignTask = async (req, res, databaseConnector) => {
    console.log("Asignando tarea a estudiante");
    try {
        const { id_tarea, id_estudiante } = req.body;
        // 1. Verificar que los campos necesarios están presentes
        if (!id_tarea || !id_estudiante) {
            if (!id_tarea)
            return res.status(400).json({ message: 'Error. Falta id_tarea. Inténtelo de nuevo'})
            else if(!id_estudiante)
            return res.status(400).json({ message: 'Error. Falta id_estudiante. Inténtelo de nuevo'})
            
        }

        await databaseConnector.transaction(async (conn) => {
            // Verificar si el estudiante ya tiene asignada la tarea
            const checkAssignmentQuery = `
            SELECT COUNT(*) AS count
            FROM ASIGNACION
            WHERE id_tarea = ? AND id_estudiante = ?
            `;
            const assignmentCheck = await conn.query(checkAssignmentQuery, [id_tarea, id_estudiante]);

            if (assignmentCheck[0].count > 0) {
            console.log("El estudiante ya tiene asignada esta tarea.");
            return res.status(400).json({ message: 'El estudiante ya tiene asignada esta tarea.' });
            }

            // 2. Insertar la tarea asignada en la tabla TAREAS_ASIGNADAS
            const insertTaskQuery = `INSERT INTO ASIGNACION (id_tarea, id_estudiante) VALUES (?, ?)`;
            await conn.query(insertTaskQuery, [id_tarea, id_estudiante]);
            // 3. Inicializar el estado de la tarea asignada
            const updateTaskStateQuery = `UPDATE ASIGNACION SET estado = 'PENDIENTE' WHERE id_tarea = ? AND id_estudiante = ?`;
            await conn.query(updateTaskStateQuery, [id_tarea, id_estudiante]);
        });

        return res.status(201).json({
            message: 'Tarea asignada exitosamente'
        });

    } catch (error) {
        console.error('Error en la transacción de asignar tarea:', error);
        return res.status(500).json({ message: 'Error al asignar tarea. Inténtelo de nuevo.', error: error.message });
    }
}

/*Placeholder generado con chatgpt. REVISAR ANTES  */
const getTasksStudent = async (req, res, databaseConnector, id_student) => {
    try {
        //console.log("Obteniendo tareas del estudiante con id:", id_student);
        const studentTasksQuery = `
            SELECT a.id_tarea
            FROM ASIGNACION a
            WHERE a.id_estudiante = ?
        `;
        //console.log("Ejecutando consulta para obtener tareas del estudiante");
        const studentTasks = await databaseConnector.query(studentTasksQuery, [id_student]);
        //console.log("Tareas del estudiante obtenidas:", studentTasks);
        const studentTaskIds = studentTasks.map(task => task.id_tarea);
        //console.log("IDs de tareas del estudiante:", studentTaskIds);


        let tasksQuery = `
            SELECT t.id_tarea, t.nombre, t.id_img AS imagen_ident, p.id_paso, p.orden, p.id_img AS url_imagen, p.url_video, p.texto
            FROM TAREA_PASOS t
            LEFT JOIN PASOS p ON t.id_tarea = p.id_tarea
        `;

        if (studentTaskIds.length > 0) {
            tasksQuery += ` WHERE t.id_tarea IN (${studentTaskIds.join(',')})`;
        
        } else {
            return res.status(200).json([]);
        }
        const imagesQuery = `
            SELECT id_img, IFNULL(CONCAT('http://localhost:8080/images/', nombre), '') AS nombre
            FROM Imagen
            WHERE id_img IN (SELECT id_img FROM TAREA_PASOS UNION SELECT id_img FROM PASOS)
        `;

        const images = await databaseConnector.query(imagesQuery);
        const imagesMap = images.reduce((acc, image) => {
            acc[image.id_img] = image.nombre;
            return acc;
        }, {});

        const tasks = await databaseConnector.query(tasksQuery);

        const formattedTasks = tasks.reduce((acc, task) => {
            if (!acc[task.id_tarea]) {
            acc[task.id_tarea] = {
                id_tarea: task.id_tarea,
                nombre: task.nombre,
                imagen_ident: imagesMap[task.imagen_ident] || null,
                pasos: []
            };
            }

            if (task.id_paso) {
            acc[task.id_tarea].pasos.push({
                id_paso: task.id_paso,
                orden: task.orden,
                url_imagen: imagesMap[task.url_imagen] || null,
                url_video: task.url_video,
                texto: task.texto
            });
            }

            return acc;
        }, {});

        const tasksArray = Object.values(formattedTasks);
        return res.status(200).json(tasksArray);
    } catch (error) {
        console.error('Error al obtener las tareas:', error);
        return res.status(500).json({ message: 'Error al obtener las tareas' });
    }
};



export default { getTasks, addTask,addStep, assignTask, getTasksStudent};