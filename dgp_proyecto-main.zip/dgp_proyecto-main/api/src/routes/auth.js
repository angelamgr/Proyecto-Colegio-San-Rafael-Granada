import jwt from 'jsonwebtoken';

/**
 * Función para autenticar un usuario y generar un token.
 * @param {Object} req - Objeto de solicitud HTTP.
 * @param {Object} res - Objeto de respuesta HTTP.
 * @param {Object} databaseConnector - Instancia de conexión a la base de datos.
 * @param {string} secretKey - Clave secreta para firmar el token.
 */
const auth = async (req, res, databaseConnector, secretKey) => {
  const { username, password } = req.body;
  try {
    const user = await databaseConnector.findUserByCredentials(username, password);
    if (user) {
      const id_rol = user.id_rol;
      const token = jwt.sign({ username, id_rol }, secretKey, { expiresIn: '1h' });
      return res.status(200).json({ token });
    }
    return res.status(401).json({ message: 'Credenciales incorrectas' });
  } catch (error) {
    console.error('Error en el proceso de autenticación:', error);
    return res.status(500).json({ message: 'Error en el servidor' });
  }
};

/**
 * Middleware para autenticar un token.
 * @param {string} secretKey - Clave secreta para verificar el token.
 * @returns {Function} Middleware de autenticación.
 */
const authenticateToken = (secretKey) => (req, res, next) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    console.log("Token no proporcionado");
    return res.status(401).json({ message: 'Token no proporcionado' });
  }

  jwt.verify(token, secretKey, (err, user) => {
    if (err) {
      if (err.name === 'TokenExpiredError') {
        console.log("Token expirado");
        return res.status(401).json({ message: 'El token ha expirado, por favor inicia sesión nuevamente' });
      }
      console.log("Token inválido:", err.message);
      return res.status(403).json({ message: 'Token inválido' });
    }

    req.user = user;
    next();
  });
};

/**
 * Middleware para verificar si el usuario tiene permisos de administrador.
 * @param {Object} req - Objeto de solicitud HTTP.
 * @param {Object} res - Objeto de respuesta HTTP.
 * @param {Function} next - Siguiente middleware.
 */
const isAdmin = (req, res, next) => {
  if (req.user && req.user.id_rol === 1) {
    return next();
  }
  console.log("Acceso denegado: no es administrador");
  return res.status(403).json({ message: 'Acceso denegado: usuario no autorizado' });
};

/**
 *  Función para autenticar un estudiante y generar un token
 * @param {*} req  - Objeto de solicitud HTTP.
 * @param {*} res  - Objeto de respuesta HTTP.
 * @param {*} databaseConnector  - Instancia de conexión a la base de datos.
 * @param {*} secretKey  - Clave secreta para firmar el token.
 */
const authStudent = async (req, res, databaseConnector, secretKey) => {
  const { usuario, method, input } = req.body;
  console.log("auth Recibido", usuario, method, input);
  if (!usuario || !method || !input) {
    return res.status(400).json({ message: "Datos de entrada incompletos." });
  }

  try {
    const query = `
    SELECT 
        u.id_user, 
        u.nombre AS usuario_nombre, 
        u.usuario, 
        u.pwd, 
        u.id_rol,
        e.id_estudiante, 
        e.pwd_distractores_real,  -- Aquí aseguramos que estamos trayendo el nuevo campo
        e.prefe_view
    FROM 
        Usuario u
    JOIN 
        Estudiante e ON u.id_user = e.id_estudiante
    WHERE 
        u.usuario = ?
`;

    const [studentData] = await databaseConnector.query(query, [usuario]);
    if (!studentData) {
      return res.status(404).json({ message: "Usuario no encontrado" });
    }
    console.log("Estudiante: ", studentData);

    let isValid = false;
    console.log("Empezando validación.");
    switch (method) {
      case "Texto":
        console.log("validando texto...");
        isValid = input === studentData.pwd;
        break;

      case "Imagenes":
      case "Pictogramas":
      case "Imagen+Texto":
      case "Pictograma+Texto":
        console.log("Validando patrón de imágenes...");
        if (!studentData.pwd_distractores_real || studentData.pwd_distractores_real.length === 0) {
          console.log("Error: No se encontraron distractores reales.");
          return res.status(404).json({ message: "No se encontraron distractores reales para este estudiante." });
        }

        console.log("input: ", input, " en bd: ", studentData.pwd_distractores_real);

        const patternIds = Array.isArray(input) ? input.map(String) : input.split(",").map(String);
        const dbPatternIds = Array.isArray(studentData.pwd_distractores_real)
          ? studentData.pwd_distractores_real.map(String)
          : studentData.pwd_distractores_real.split(",").map((id) => id.trim());

        isValid = patternIds.length === dbPatternIds.length &&
          patternIds.every((id, index) => id === dbPatternIds[index]);

        break;

      default:
        return res.status(402).json({ message: "Método de autenticación no soportado" });
    }

    if (!isValid) {
      console.log("No valido");
      return res.status(401).json({ message: "Credenciales incorrectas" });
    } else {
      console.log("Ok, todo valido");
    }

    // Si la autenticación es válida, generar el token JWT
    const { id_rol, id_user } = studentData; // Tomamos los datos del estudiante para el JWT
    console.log("id_rol: ", id_rol, " id_user: ", id_user); 
    let nombre = studentData.usuario_nombre;
    let token = jwt.sign({ usuario, id_rol, id_student: id_user, nombre}, secretKey, { expiresIn: "1h" });
    console.log("ok, token: ", token);
    return res.status(200).json({ token });
  } catch (error) {
    console.error("Error en el proceso de autenticación de estudiante:", error);
    return res.status(500).json({ message: "Error en el servidor" });
  }
};


export { auth, authenticateToken, isAdmin, authStudent };
