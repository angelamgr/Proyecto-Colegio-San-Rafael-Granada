const addMenu = async (req, res, databaseConnector) => {
  const { nombre } = req.body;
  const imagen = req.file; // Obtener el archivo de imagen del request (si existe)

  /**
   * 1. Verificar que el campo nombre no esté vacío
   * 2. Si se envió una imagen, insertarla en la tabla Imagen
   * 3. Insertar el menú en la tabla Menu, asociando la imagen (si existe)
   * 4. Devolver una respuesta indicando que el menú fue añadido correctamente
   */

  // 1. Verificar que el campo nombre no esté vacío
  if (!nombre) {
      return res.status(400).json({ message: 'El campo nombre es obligatorio.' });
  }

  try {
      let id_img = null;

      // 2. Si se envió una imagen, insertarla en la tabla Imagen
      await databaseConnector.transaction(async (conn) => {
        if (imagen) {
            const imageQuery = "INSERT INTO Imagen (nombre, tipo) VALUES (?, ?)";
            const imageType = imagen.mimetype.startsWith('image/') ? 'Imagen' : 'Pictograma';
            const imageName = imagen.filename; // El nombre del archivo de imagen
            const imageResult = await databaseConnector.query(imageQuery, [imageName, imageType]);

            id_img = imageResult.insertId; // Obtener el id_img de la imagen insertada
        }

        // 3. Insertar el menú en la tabla Menu, asociando la imagen (si existe)
        const insertMenuQuery = "INSERT INTO Menu (nombre, id_img) VALUES (?, ?)";
        await databaseConnector.query(insertMenuQuery, [nombre, id_img || null]);
      });

      // 4. Devolver una respuesta indicando que el menú fue añadido correctamente
      return res.status(200).json({ message: 'Menú añadido correctamente.' });

  } catch (error) {
      console.error('Error al añadir menú:', error);
      return res.status(500).json({ message: 'Error al añadir menú. Por favor, verifica los datos.' });
  }
};


const deleteMenuById = async (req, res, databaseConnector) => {
    const { id_menu } = req.params;

    if (!id_menu) {
      return res.status(400).json({ message: 'El campo id_menu es obligatorio.' });
    }

    try {
      let response = null;
      await databaseConnector.transaction(async (conn) => {
        const query = 'DELETE FROM Menu WHERE id_menu = ?';
        response = await databaseConnector.query(query,[id_menu]);
      });
      return res.status(200).json({ message: 'Menú eliminado correctamente' });
    } catch (error) {
      console.error ('Error al eliminar menú:', error);
      return res.status(500).json({ message: 'Error al eliminar menú. Por favor, verifica los datos.' });
    }
};

const getMenus = async (req, res, databaseConnector) => {
    try {
      const query = `
            SELECT 
          m.id_menu, 
          m.nombre AS menu_nombre, 
          CONCAT('http://localhost:8080/images/', i.nombre) AS imagen_url
          FROM 
          Menu m
          LEFT JOIN 
          Imagen i ON m.id_img = i.id_img;
    `;
      const menues = await databaseConnector.query(query);
      return res.status(200).json(menues);
      } catch (error) {
        console.error('Error al consultar menus:', error);
        return res.status(500).json({ message: 'Server: Error al consultar menus' });
      }
};

module.exports = { addMenu, deleteMenuById, getMenus };
