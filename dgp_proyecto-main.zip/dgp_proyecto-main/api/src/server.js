const express = require("express");
const cors = require("cors");

/*LOGS */
const morgan = require("morgan");
const rfs = require("rotating-file-stream");

/* UPLOAD FILES */
const upload_file = require("./multer_cfg");

/* MODULES */
const DBConnector = require("./db_connector");
const {
    addStudent,
    getStudentIdByUser,
    getStudents,
    getStudentPwdDist,
    deleteStudent,
} = require("./routes/students");
const { getMenus, addMenu, deleteMenuById } = require("./routes/menus");
const {
    isAdmin,
    authenticateToken,
    auth,
    authStudent,
} = require("./routes/auth");
const { getTasks, addTask, addStep, assignTask, getTasksStudent } =
    require("./routes/tasks").default;
const path = require("path");

class Server {
    constructor() {
        this.app = express();

        this.port = process.env.PORT || 8080;
        this.SECRET_KEY = "your_secret_key";

        this.databaseConnector = DBConnector.getInstance();
        this.connectToDatabase();
        this.setupMiddleWare();
        this.setupRoutes();
    }

    setupMiddleWare() {
        const logStream = rfs.createStream("access.log", {
            interval: "1d",
            path: "./logs",
        });
        this.app.use(morgan("combined", { stream: logStream }));
        this.app.use(cors());
        this.app.use(express.json());
        this.app.use(express.urlencoded({ extended: true })); // Para manejar formularios
        this.app.use("/images", express.static("uploads"));
    }

    async connectToDatabase() {
        try {
            await this.databaseConnector.connect();
        } catch (error) {
            console.error(error);
        }
    }

    setupRoutes() {
        this.app.get("/", this.index.bind(this));

        /*Login*/
        this.app.post("/api/auth", (req, res) =>
            auth(req, res, this.databaseConnector, this.SECRET_KEY),
        );
        this.app.post("/api/auth_student", (req, res) =>
            authStudent(req, res, this.databaseConnector, this.SECRET_KEY),
        );

        /*Estudiante*/
        this.app.post(
            "/api/add_student",
            authenticateToken(this.SECRET_KEY),
            isAdmin,
           
            upload_file.fields([
                { name: "profileImage", maxCount: 1 },
                { name: 'distractors', maxCount: 10 },
            ]),
            (req, res) => addStudent(req, res, this.databaseConnector),
        );
        
        this.app.get(
            "/api/students",
            authenticateToken(this.SECRET_KEY),
            isAdmin,
            (req, res) => getStudents(req, res, this.databaseConnector),
        );
        this.app.get("/api/show_students", (req, res) =>
            getStudents(req, res, this.databaseConnector),
        );
        this.app.delete(
            "/api/delete_student/:id_student",
            authenticateToken(this.SECRET_KEY),
            isAdmin,
            (req, res) => deleteStudent(req, res, this.databaseConnector),
        );
        this.app.get(
            "/api/student_id/:usuario",
            authenticateToken(this.SECRET_KEY),
            isAdmin,
            (req, res) => getStudentIdByUser(req, res, this.databaseConnector),
        );
        this.app.get(
            "/api/student/:usuario/pwd_dist",
            (req, res) => getStudentPwdDist(req, res, this.databaseConnector),
        );

        /*Menu comedor*/
        this.app.post(
            "/api/add_menu",
            authenticateToken(this.SECRET_KEY),
            isAdmin,
            upload_file.single("imagen"),
            (req, res) => addMenu(req, res, this.databaseConnector),
        );
        this.app.delete(
            "/api/menu/:id_menu",
            authenticateToken(this.SECRET_KEY),
            isAdmin,
            (req, res) => deleteMenuById(req, res, this.databaseConnector),
        );
        this.app.get("/api/menus", authenticateToken(this.SECRET_KEY), (req, res) =>
            getMenus(req, res, this.databaseConnector),
        );

        /*Tareas*/
        this.app.post(
            "/api/add_task",
            authenticateToken(this.SECRET_KEY),
            isAdmin,
            upload_file.single("taskImage"),
            (req, res) => addTask(req, res, this.databaseConnector),
        );
        this.app.post(
            "/api/add_step",
            authenticateToken(this.SECRET_KEY),
            isAdmin,
            upload_file.fields([
                { name: "stepImage", maxCount: 1 },
                { name: "pictoImage", maxCount: 1 },
            ]),
            (req, res) => addStep(req, res, this.databaseConnector),
        );
        this.app.get(
            "/api/tasks",
            authenticateToken(this.SECRET_KEY),
            isAdmin,
            (req, res) => getTasks(req, res, this.databaseConnector),
        );
        this.app.delete(
            "/api/task/:id_task",
            authenticateToken(this.SECRET_KEY),
            isAdmin,
            (req, res) => {
                const { id_task } = req.params;
                // Add your logic to delete the task by id_task using this.databaseConnector
                // For example:
                this.databaseConnector
                    .deleteTaskWithStepsById(id_task)
                    .then(() =>
                        res.status(200).json({ message: "Tarea eliminada correctamente" }),
                    )
                    .catch((error) =>
                        res.status(500).json({
                            error: "Algo ha fallado al intentar eliminar la tarea",
                            details: error,
                        }),
                    );
            },
        );
        this.app.post(
            "/api/assign_task",
            authenticateToken(this.SECRET_KEY),
            isAdmin,
            (req, res) => assignTask(req, res, this.databaseConnector),
        );
        this.app.get(
            "/api/tasks/:id_student",
            authenticateToken(this.SECRET_KEY),
            (req, res) => {
                const { id_student } = req.params;
                getTasksStudent(req, res, this.databaseConnector, id_student);
            },
        );
    }

    async index(req, res) {
        res.status(200).json({
            status: "api live",
            db_status: this.databaseConnector.connection
                ? "connected"
                : "disconnected",
        });
    }

    listen() {
        this.app.listen(this.port, () => {
            console.log(`Servidor corriendo en el puerto ${this.port}`);
        });
    }
}

module.exports = Server;
